# CareerUp Schema Integrity Audit — 15 October 2026

## Finding
No schema changes were made in this correction release. A matches the earlier reviewed 48-table source byte for byte. B matches the isolated 54-table source byte for byte. The evidence does not support deleting majors or disciplines as recent speculative additions. However, no signed team approval artifact was found: “present in the original” and “team approved” are different claims.

## Questionable definitions and their origins
| Definition | Earliest available evidence | Requirement and rationale | Disposition |
|---|---|---|---|
| academic_disciplines | Original 45-table work/original.dbml, lines 97–101; already in earliest tracked package e83be28 (12 October) | FRD recruiter Search and Discover Students; Administrator Manage Skills and Academic Categories; feed discipline filters | Retain as requirements-supported original design; explicit team approval unverified. Not a teammate enhancement. |
| majors | Original 45-table DBML lines 103–111; same earliest tracked package | Student profile stores a major; recruiters filter majors; admins manage major categories | Retain; a major is a degree/program category, while a discipline groups related majors. Separate tables avoid repeated discipline names. The exact hierarchy is a modeling assumption for team confirmation. |
| majors.discipline_id → academic_disciplines | Original 45-table DBML | One required discipline per major; one discipline can have zero or many majors | Retain original cardinality. FRD supports both concepts, but does not mandate one discipline per major. Confirm interdisciplinary policy with team; do not call it explicitly approved. |
| posts.discipline_id → academic_disciplines | Original 45-table DBML line 181 | Create Portfolio Post permits major or academic category; feed/recruiter filters use discipline | Retain optional reference. A post may have no discipline; a discipline can categorize many posts. The post's subject can differ from its author's academic program, so it is not redundant with the student profile. |
| posts.major_id → majors and mutually exclusive direct discipline | Absent from original 45-table file; present in earliest tracked audited package e83be28 | FRD explicitly permits major OR discipline. Existing audited design permits either; a major's discipline is derived instead of storing both | Earlier audit/modeling revision, not the later teammate proposal. Specific human approval cannot be established. Keep as review-pending in this preserved release rather than silently deleting or calling approved. |
| merged_into_* category references | Absent from original 45-table definitions; present in earliest tracked audited package e83be28 | FRD Administrator can merge/deactivate majors, disciplines, industries and skills | Earlier audit refinement, not teammate proposal. Retain with explicit approval-status uncertainty; self/cycle checks remain application policy. |

## Scope of the 48-table baseline
The three additional tables relative to the available original 45-table input are: account_reviews, application_materials, application_notes. These are earlier audit additions, not changes made by this release. See the per-table audit for requirement mapping. They cover attributable account approval, additional application materials and employer application notes as modeled in that audit. The FRD supports account administration, other required application information, and recruiter notes/decisions respectively. Exact granularity is a design choice, not a requirement to use precisely 48 tables.

A supports the full five-role system; the three competition cases cover only part of it. Existing lookups and bridges prevent repeated names and many-valued fields. Table count alone does not establish quality or necessity. No demonstrated duplicate was found in the questioned taxonomy definitions. Combining majors/disciplines would require a type/hierarchy policy and would alter existing references, rather than simply remove unused complexity.

## Approval uncertainty and team decisions
1. Confirm the existing one-discipline-per-major hierarchy and single major-or-discipline classification per post.
2. Confirm the earlier audit additions and category-merge references; existing files and Git history demonstrate provenance, not individual human approval.
3. B's six additional tables and six existing-table fields are experimental user-authorized proposal implementations. They do not leak into A. Adoption, retention, retry transitions and taxonomy administration still need group agreement.

## Version B boundary
Snapshots add three tables and evidence sealing; workflow adds two history/transition tables; taxonomy adds aliases and an optional parent; removal reuses moderation_actions with timestamps/checks; discovery adds two indexes. These originate from the supplied five-proposal text, not new FRD mandates. No further schema additions were introduced during the UI correction.

## Technical limits
Definitions, dictionary fields, FK tuples and cardinalities are compared against the actual retained models. MySQL DDL remains unexecuted; do not treat static checks as proof of runtime behavior. Existing application authorization, cycle detection, state/log transactions and permanent media preservation remain Sprint III work.

## Evidence paths
- work/original.dbml (available original 45-table input; original author cannot be independently authenticated)
- work/requirements-current.txt (extracted FRD): Create Portfolio Post lines 44–45; Search and Discover Students 72–73; Manage Skills and Academic Categories 159–160; design requirements 177–180.
- earliest tracked audited package e83be28, 12 October 2026; readable-ERD reorganization 04754b3, 14 October.
- outputs/professional-database/careerup-reviewed.dbml and its dictionary/rules.
- preserved outputs/presentation-focus-v2 packages and branch commit 6501559.
