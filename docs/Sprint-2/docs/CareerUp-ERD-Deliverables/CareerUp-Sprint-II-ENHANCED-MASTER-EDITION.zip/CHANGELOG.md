# Master ERD edition changes

- Eight opening cards: seven complete chapter master ERDs plus the full presentation.
- Visible Chapter Master ERDs selector, with previews of all seven complete diagrams.
- Separate seven-master-only presentation; smaller relationship diagrams are optional.
- Richer CareerUp navy/purple visual styling, soft button lift/glow and press feedback, restrained table/line emphasis, lighter domain panels and reduced-motion support.
- Removed repeated relationship explanations. Public notes explain the connection, why it helps, stored information and a documented business rule.
- Rewritten private scripts, separate seven-master scripts and updated offline speaking notes. Exact technical material remains optional.
- Existing database schemas preserved byte for byte.
