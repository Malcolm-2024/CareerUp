# Version B relationship register — 118 FKs

All baseline relationships remain; R110–R118 are experimental additions. Logical child minima are distinguished from physical FK enforcement.

| ID | Child / columns | Parent / columns | Parent per child | Children per parent |
|---|---|---|---|---|
| R001 | role_permissions (role_id) | roles (role_id) | 1 | 0..* |
| R002 | role_permissions (permission_id) | permissions (permission_id) | 1 | 0..* |
| R003 | users (role_id) | roles (role_id) | 1 | 0..* |
| R004 | users (school_id) | schools (school_id) | 0..1 | 0..* |
| R005 | student_profiles (user_id) | users (user_id) | 1 | 0..1 |
| R006 | student_profiles (major_id) | majors (major_id) | 1 | 0..* |
| R007 | academic_disciplines (merged_into_discipline_id) | academic_disciplines (discipline_id) | 0..1 | 0..* |
| R008 | majors (discipline_id) | academic_disciplines (discipline_id) | 1 | 0..* |
| R009 | majors (merged_into_major_id) | majors (major_id) | 0..1 | 0..* |
| R010 | industries (merged_into_industry_id) | industries (industry_id) | 0..1 | 0..* |
| R011 | skills (merged_into_skill_id) | skills (skill_id) | 0..1 | 0..* |
| R012 | student_skills (student_user_id) | student_profiles (user_id) | 1 | 0..* |
| R013 | student_skills (skill_id) | skills (skill_id) | 1 | 0..* |
| R014 | companies (industry_id) | industries (industry_id) | 1 | 0..* |
| R015 | companies (approved_by_user_id) | users (user_id) | 0..1 | 0..* |
| R016 | company_locations (company_id) | companies (company_id) | 1 | 0..* |
| R017 | company_memberships (company_id) | companies (company_id) | 1 | 0..* |
| R018 | company_memberships (user_id) | users (user_id) | 1 | 0..* |
| R019 | company_memberships (reviewed_by_user_id) | users (user_id) | 0..1 | 0..* |
| R020 | posts (author_user_id) | users (user_id) | 1 | 0..* |
| R021 | posts (company_id) | companies (company_id) | 0..1 | 0..* |
| R022 | posts (discipline_id) | academic_disciplines (discipline_id) | 0..1 | 0..* |
| R023 | posts (major_id) | majors (major_id) | 0..1 | 0..* |
| R024 | post_media (post_id) | posts (post_id) | 1 | 1..* |
| R025 | post_skills (post_id) | posts (post_id) | 1 | 0..* |
| R026 | post_skills (skill_id) | skills (skill_id) | 1 | 0..* |
| R027 | collaboration_verifications (company_id) | companies (company_id) | 1 | 0..* |
| R028 | collaboration_verifications (reviewed_by_user_id) | users (user_id) | 0..1 | 0..* |
| R029 | collaboration_verifications (showcased_by_user_id) | users (user_id) | 0..1 | 0..* |
| R030 | user_follows (follower_user_id) | users (user_id) | 1 | 0..* |
| R031 | user_follows (followed_user_id) | users (user_id) | 1 | 0..* |
| R032 | post_likes (post_id) | posts (post_id) | 1 | 0..* |
| R033 | post_likes (user_id) | users (user_id) | 1 | 0..* |
| R034 | post_comments (post_id) | posts (post_id) | 1 | 0..* |
| R035 | post_comments (user_id) | users (user_id) | 1 | 0..* |
| R036 | post_saves (post_id) | posts (post_id) | 1 | 0..* |
| R037 | post_saves (user_id) | users (user_id) | 1 | 0..* |
| R038 | post_shares (post_id) | posts (post_id) | 1 | 0..* |
| R039 | post_shares (user_id) | users (user_id) | 1 | 0..* |
| R040 | saved_companies (user_id) | users (user_id) | 1 | 0..* |
| R041 | saved_companies (company_id) | companies (company_id) | 1 | 0..* |
| R042 | view_events (viewer_user_id) | users (user_id) | 1 | 0..* |
| R043 | view_events (post_id) | posts (post_id) | 0..1 | 0..* |
| R044 | view_events (company_id) | companies (company_id) | 0..1 | 0..* |
| R045 | view_events (job_id) | job_postings (job_id) | 0..1 | 0..* |
| R046 | job_postings (company_id) | companies (company_id) | 1 | 0..* |
| R047 | job_postings (posted_by_user_id) | users (user_id) | 1 | 0..* |
| R048 | job_skills (job_id) | job_postings (job_id) | 1 | 0..* |
| R049 | job_skills (skill_id) | skills (skill_id) | 1 | 0..* |
| R050 | job_disciplines (job_id) | job_postings (job_id) | 1 | 0..* |
| R051 | job_disciplines (discipline_id) | academic_disciplines (discipline_id) | 1 | 0..* |
| R052 | applications (job_id) | job_postings (job_id) | 1 | 0..* |
| R053 | applications (student_user_id) | student_profiles (user_id) | 1 | 0..* |
| R054 | applications (status_id) | application_statuses (status_id) | 1 | 0..* |
| R055 | application_status_history (application_id) | applications (application_id) | 1 | 0..* |
| R056 | application_status_history (status_id) | application_statuses (status_id) | 1 | 0..* |
| R057 | application_status_history (changed_by_user_id) | users (user_id) | 1 | 0..* |
| R058 | job_invitations (job_id) | job_postings (job_id) | 1 | 0..* |
| R059 | job_invitations (recruiter_user_id) | users (user_id) | 1 | 0..* |
| R060 | job_invitations (student_user_id) | student_profiles (user_id) | 1 | 0..* |
| R061 | candidate_lists (recruiter_user_id) | users (user_id) | 1 | 0..* |
| R062 | candidate_list_items (list_id) | candidate_lists (list_id) | 1 | 0..* |
| R063 | candidate_list_items (student_user_id) | student_profiles (user_id) | 1 | 0..* |
| R064 | conversations (created_by_user_id) | users (user_id) | 1 | 0..* |
| R065 | conversation_participants (conversation_id) | conversations (conversation_id) | 1 | 1..* |
| R066 | conversation_participants (user_id) | users (user_id) | 1 | 0..* |
| R067 | notifications (recipient_user_id) | users (user_id) | 1 | 0..* |
| R068 | notifications (target_post_id) | posts (post_id) | 0..1 | 0..* |
| R069 | notifications (target_comment_id) | post_comments (comment_id) | 0..1 | 0..* |
| R070 | notifications (target_user_id) | users (user_id) | 0..1 | 0..* |
| R071 | notifications (target_company_id) | companies (company_id) | 0..1 | 0..* |
| R072 | notifications (target_job_id) | job_postings (job_id) | 0..1 | 0..* |
| R073 | notifications (target_application_id) | applications (application_id) | 0..1 | 0..* |
| R074 | notifications (target_invitation_id) | job_invitations (invitation_id) | 0..1 | 0..* |
| R075 | notifications (target_verification_id) | collaboration_verifications (verification_id) | 0..1 | 0..* |
| R076 | notifications (target_conversation_id) | conversations (conversation_id) | 0..1 | 0..* |
| R077 | notifications (target_report_id) | reports (report_id) | 0..1 | 0..* |
| R078 | notifications (target_membership_id) | company_memberships (membership_id) | 0..1 | 0..* |
| R079 | notifications (target_assignment_id) | advisor_student_assignments (assignment_id) | 0..1 | 0..* |
| R080 | advisor_student_assignments (advisor_user_id) | users (user_id) | 1 | 0..* |
| R081 | advisor_student_assignments (student_user_id) | student_profiles (user_id) | 1 | 0..* |
| R082 | advisor_student_assignments (assigned_by_user_id) | users (user_id) | 0..1 | 0..* |
| R083 | opportunity_recommendations (assignment_id) | advisor_student_assignments (assignment_id) | 1 | 0..* |
| R084 | opportunity_recommendations (job_id) | job_postings (job_id) | 1 | 0..* |
| R085 | reports (reporter_user_id) | users (user_id) | 1 | 0..* |
| R086 | reports (target_post_id) | posts (post_id) | 0..1 | 0..* |
| R087 | reports (target_comment_id) | post_comments (comment_id) | 0..1 | 0..* |
| R088 | reports (target_user_id) | users (user_id) | 0..1 | 0..* |
| R089 | reports (target_message_id) | messages (message_id) | 0..1 | 0..* |
| R090 | reports (target_job_id) | job_postings (job_id) | 0..1 | 0..* |
| R091 | reports (target_company_id) | companies (company_id) | 0..1 | 0..* |
| R092 | moderation_actions (report_id) | reports (report_id) | 1 | 0..* |
| R093 | moderation_actions (admin_user_id) | users (user_id) | 1 | 0..* |
| R094 | system_settings (updated_by_user_id) | users (user_id) | 0..1 | 0..* |
| R095 | application_materials (application_id) | applications (application_id) | 1 | 0..* |
| R096 | application_notes (application_id) | applications (application_id) | 1 | 0..* |
| R097 | application_notes (recruiter_user_id) | users (user_id) | 1 | 0..* |
| R098 | account_reviews (subject_user_id) | users (user_id) | 1 | 0..* |
| R099 | account_reviews (reviewed_by_user_id) | users (user_id) | 1 | 0..* |
| R100 | messages (conversation_id, sender_user_id) | conversation_participants (conversation_id, user_id) | 1 | 0..* |
| R101 | job_postings (company_id, location_id) | company_locations (company_id, location_id) | 0..1 | 0..* |
| R102 | collaboration_verifications (post_id, company_id) | posts (post_id, company_id) | 1 | 0..1 |
| R103 | application_portfolio_posts (application_id, student_user_id) | applications (application_id, student_user_id) | 1 | 1..* |
| R104 | application_portfolio_posts (post_id, student_user_id) | posts (post_id, author_user_id) | 1 | 0..* |
| R105 | applications (invitation_id, job_id, student_user_id) | job_invitations (invitation_id, job_id, student_user_id) | 0..1 | 0..1 |
| R106 | portfolio_feedback (assignment_id, student_user_id) | advisor_student_assignments (assignment_id, student_user_id) | 1 | 0..* |
| R107 | portfolio_feedback (post_id, student_user_id) | posts (post_id, author_user_id) | 0..1 | 0..* |
| R108 | conversations (job_id) | job_postings (job_id) | 0..1 | 0..* |
| R109 | conversations (application_id, job_id) | applications (application_id, job_id) | 0..1 | 0..* |
| R110 | skills (parent_skill_id) | skills (skill_id) | 0..1 | 0..* |
| R111 | skill_aliases (skill_id) | skills (skill_id) | 1 | 0..* |
| R112 | application_post_snapshots (application_id, source_author_user_id) | applications (application_id, student_user_id) | 1 | 0..* |
| R113 | application_snapshot_media (snapshot_id) | application_post_snapshots (snapshot_id) | 1 | 0..* |
| R114 | application_snapshot_skills (snapshot_id) | application_post_snapshots (snapshot_id) | 1 | 0..* |
| R115 | application_portfolio_posts (snapshot_id, application_id, post_id, student_user_id) | application_post_snapshots (snapshot_id, application_id, source_post_id, source_author_user_id) | 1 | 0..1 |
| R116 | collaboration_verification_history (verification_id) | collaboration_verifications (verification_id) | 1 | 0..* |
| R117 | collaboration_verification_history (changed_by_user_id) | users (user_id) | 1 | 0..* |
| R118 | collaboration_verification_history (from_status, to_status) | verification_transitions (from_status, to_status) | 0..1 | 0..* |

Snapshot media may be staged before sealing. Snapshot sealing requires media; application sealing requires at least one sealed attachment. FKs alone do not enforce those minima.
