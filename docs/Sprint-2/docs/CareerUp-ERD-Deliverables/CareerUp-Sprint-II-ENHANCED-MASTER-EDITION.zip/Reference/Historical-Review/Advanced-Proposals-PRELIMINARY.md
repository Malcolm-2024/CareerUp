# Advanced database proposals — separate preliminary assessment

14 October 2026. The actual GitHub document could not be retrieved. This evaluates only the five proposals supplied by the team, against the local FRD, reviewed 48-table model, dictionary, rules and three cases. It is not a line-by-line review of the teammate's document. Reassess specific SQL or design claims when its text is supplied. None of these proposals has been implemented or approved.

| Proposal | Usefulness | Classification | Recommendation |
|---|---:|---|---|
| Immutable application portfolio snapshots | 5/10 | Future enhancement | Decide whether applications must preserve submission-time evidence before introducing versioning. |
| Collaboration verification state workflows | 8/10 | Improve existing design | Explain current states, authorization and allowed transitions using existing fields. Do not add workflow tables. |
| Normalized skills and discipline taxonomies | 9/10 | Improve existing design | Existing design already supplies this. Clarify it; avoid duplicate taxonomy infrastructure. |
| Soft deletes and moderation audit logs | 6/10 | Improve existing design | Inventory existing statuses/actions; settle retention per entity before adding universal deletion fields. |
| Recruiter discovery indexes | 7/10 | Future enhancement | Plan from actual filters and query plans in Sprint III; avoid speculative duplicate indexes. |

## 1. Immutable application portfolio snapshots
Already present: applications and application_portfolio_posts preserve which live post IDs were selected; composite FKs restrict attachments to the applicant's own posts. They do not freeze the description, media, skill tags or verification state at submission. The current FRD permits portfolio attachments but does not explicitly demand immutable evidence. BR41 flags post-edit/retention decisions as unresolved.

Value versus complexity: frozen evidence is useful if recruiters must review exactly what was submitted. It adds versioning, asset-retention and privacy/deletion decisions and may confuse the existing three-case explanation. It is not justified solely to sound sophisticated.

Changes: a true implementation would require versioned post/evidence records or snapshot fields plus an application-to-version link; the exact shape depends on the unavailable document. A JSON copy is MySQL-compatible but loses ordinary FK validation inside JSON and does not freeze an overwriteable media URL. Verification must bind to the captured version to avoid misleading claims.

Simpler option: explicitly document that attachments reference current portfolio content and disclose edits; or propose restricting relevant edits after submission. Neither is currently an approved policy or database constraint. Sprint II competition benefit is modest until the team chooses the requirement. No snapshot change now.

## 2. Collaboration verification workflows/state machines
Already present: collaboration_verifications holds a unique post reference, company, status, reviewer and review time. Existing checks validate aspects of review-state completeness. Companies, users, roles and company_memberships support the authority check. A post can have zero or one verification record; this is not a multi-attempt verification history.

FRD fit: strong; company approval by an authorized representative is explicit. Distinguish a valid stored status from a legal transition. ENUM/CHECK can constrain values and row shape; they cannot alone compare old/new states or establish the actor's active company authority. Sprint III authorization and transactional state checks are still needed.

Changes: documentation can explain existing pending/approved/rejected paths with no schema change, subject to the exact declared enum. New attempt/history tables or a generic workflow engine are unnecessary unless resubmission/auditing is agreed. MySQL supports transactions and conditional updates; concurrent approval/rejection should be handled atomically.

Simpler option: one current-state row and a small transition/authorization table in documentation. This strengthens competition reasoning more than adding entities. Clarification is recommended, not implemented as a new policy.

## 3. Normalized skills and discipline taxonomies
Already present: schools, academic_disciplines, majors, industries and skills; student_skills, post_skills, job_skills and job_disciplines model reusable associations. Majors reference disciplines. Merge destinations and active flags already exist. These support FRD discovery filters and skill-tagged evidence.

Value: high for the existing design; low incremental value from proposing it again. Adding parallel skill/category tables would duplicate concepts and worsen navigation. An arbitrary universal hierarchy or synonym engine is beyond the current FRD.

Changes: no new tables needed for basic normalization. Explaining existing reference/junction tables is a documentation refinement. MySQL FK/UNIQUE constraints support this model. The separately identified AUTO_INCREMENT/CHECK correction is a real compatibility fix, not adoption of this proposal.

Simpler option: present the current taxonomy sheet and one student/post/job skill association. No added taxonomy infrastructure. Useful competition explanation: one shared skill label can be reused without repeated spelling variants.

## 4. Soft deletes and moderation audit logs
Already present: entity-specific status/active fields represent lifecycle states; reports and moderation_actions record moderation activity; account_reviews records approval decisions. This is partial, purpose-specific support, not a universal soft-delete mechanism. A status does not automatically retain every previous value or identify every actor.

FRD fit: moderation is required; universal indefinite retention and complete change auditing are not explicit. Extra deleted_at/deleted_by fields everywhere would introduce filtering, uniqueness and restoration rules across all workflows. Audit retention and access may be as important as retention itself.

Changes: simple policy/enforcement documentation can reuse current states. Universal soft deletion would change existing tables; a generic audit log would add a table and needs scope/retention decisions. MySQL supports timestamps and log tables, but a UNIQUE email remains reserved after a soft deletion; active-only uniqueness and cascading behavior require deliberate design. An audit table without immutable permissions is not tamper-proof.

Simpler option: retain referenced records using existing inactive/moderated states and existing action records where required, after team approval of per-entity retention. Do not assert this is already globally enforced. Explain current moderation evidence for Sprint II; defer broad audit infrastructure.

## 5. Recruiter discovery indexing strategies
Already present: PKs, unique tuples and FK-supporting indexes provide basic access paths. Recruiter filters on major, skills, graduation year and verified work are explicit FRD needs, but a filter requirement alone does not prove a specific composite index is useful.

Value: sensible implementation work, weaker Sprint II competition value than correct cardinality and clear diagrams. More indexes increase write/storage costs. Avoid duplicating a PK or a composite index's usable leftmost prefix; a low-selectivity status index is not automatically useful. Reverse skill-junction lookups may need a different leading column from student-first PKs.

Changes: typically indexes on existing tables, no new entities or relationships. Exact candidates require reviewing existing index order, concrete JOIN/filter/order patterns, realistic data and EXPLAIN. MySQL B-tree composite indexes use leftmost prefixes; EXPLAIN ANALYZE is available in MySQL 8.0.18+ and executes the query. Full-text is a separate choice, not a substitute for relational skill filters.

Simpler option: document a small discovery-query/index review task for Sprint III. Do not claim measured speed improvements without measurements. No indexing changes now.

## Decision
Do not add new tables for these ideas in Sprint II. Existing workflow/taxonomy/moderation support deserves clearer explanation; snapshots and performance tuning require product decisions or implementation evidence. The ratings measure relevance to CareerUp, not a promise that the teammate's unavailable implementation is correct. Professor Allen's readability goal favors showing existing relationships clearly before expanding scope.

MySQL primary references: https://dev.mysql.com/doc/refman/8.0/en/create-table-check-constraints.html ; https://dev.mysql.com/doc/refman/8.0/en/multiple-column-indexes.html ; https://dev.mysql.com/doc/refman/8.0/en/explain.html ; https://dev.mysql.com/doc/refman/8.0/en/json.html
