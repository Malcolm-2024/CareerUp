# Version B — experimental index supplement

Group approval pending. Version A remains the submission candidate.

Only change: add the non-unique index `ix_student_discovery_major_year` on `student_profiles (major_id, graduation_year)`.
The Functional Requirements explicitly support recruiter filters by major and graduation year. This index is a plausible access path for that combination. It does not speed every filter, replace authorization, alter cardinalities, or guarantee fast discovery. Measure representative queries with EXPLAIN and data before retaining it.

No tables, fields, relationships, unique constraints, CHECKs, business rules or competition records changed. The ERDs are therefore identical. The canonical Version B DBML, model, JSON dictionary and interactive dictionary include the index. The standalone dictionary has an index note; a separate PDF index supplement is included. Other logical-design exports remain accurate because the logical structure is unchanged. Historical audits describe the baseline; read this supplement for the sole experimental physical change.

The proposed `verified_status` is not a column in student_profiles. Verification belongs to collaboration_verifications; an index cannot span columns in several tables. MySQL does not allow indexes on ordinary views. No view index, new verified flag or speculative covering-index collection was added.

InnoDB requires FK support indexes and may create them automatically. The new two-column index is not equivalent to assuming the major FK alone covers the graduation-year filter. It may reduce reads for suitable queries, at the cost of storage and maintenance on writes. No benchmark or database execution was performed.

No performance or implemented-app claims should be made in the competition. All three use cases and their main scripts stay the same. If asked, explain the index during the dictionary/reference discussion.

Sources: https://dev.mysql.com/doc/refman/8.0/en/multiple-column-indexes.html
https://dev.mysql.com/doc/refman/8.0/en/create-table-foreign-keys.html
https://dev.mysql.com/doc/mysql-reslimits-excerpt/8.0/en/view-restrictions.html
