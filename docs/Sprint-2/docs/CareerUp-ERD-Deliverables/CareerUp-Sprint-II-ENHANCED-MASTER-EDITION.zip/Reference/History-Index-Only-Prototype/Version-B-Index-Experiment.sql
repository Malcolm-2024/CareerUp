-- Version B experiment only. Not executed. Apply only to a baseline MySQL database after team approval.
-- Targets the FRD recruiter filters by major and graduation year; not all discovery queries.
CREATE INDEX ix_student_discovery_major_year
  ON student_profiles (major_id, graduation_year);

-- Planned benchmark query; illustrative parameter values, not a universal discovery view.
EXPLAIN SELECT user_id FROM student_profiles
  WHERE major_id = 1 AND graduation_year = 2027;

-- Proposed rollback if the experiment is not retained:
-- DROP INDEX ix_student_discovery_major_year ON student_profiles;
