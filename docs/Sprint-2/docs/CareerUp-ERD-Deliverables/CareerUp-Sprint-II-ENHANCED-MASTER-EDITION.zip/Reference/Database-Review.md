# Experimental B audit

54 tables; 337 fields; 118 FKs. Six new tables, 38 new fields, nine new FKs, two non-unique discovery indexes, explicit sealing and audit triggers.

See Database-Review.html, Business-Rules.html and careerup-enhanced-mysql.sql for the current complete design and limitations.
