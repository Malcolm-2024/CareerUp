-- CareerUp Version B EXPERIMENTAL — MySQL 8.0.16+ / InnoDB.

-- Select an EMPTY experimental database. Not executed or benchmarked by Codex.

-- Never import over Version A. Application/storage workflows are documented, not implemented here.

CREATE TABLE `roles` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) NOT NULL,
  `description` varchar(255) NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE (`role_name`)
) ENGINE=InnoDB;

CREATE TABLE `permissions` (
  `permission_id` int NOT NULL AUTO_INCREMENT,
  `permission_code` varchar(60) NOT NULL,
  `description` varchar(255) NULL,
  PRIMARY KEY (`permission_id`),
  UNIQUE (`permission_code`)
) ENGINE=InnoDB;

CREATE TABLE `role_permissions` (
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`)
) ENGINE=InnoDB;

CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `school_id` int NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(80) NOT NULL,
  `last_name` varchar(80) NOT NULL,
  `profile_photo_url` varchar(500) NULL,
  `headline` varchar(150) NULL,
  `bio` text NULL,
  `phone` varchar(30) NULL,
  `status` ENUM('PENDING_APPROVAL', 'ACTIVE', 'SUSPENDED', 'BANNED', 'DEACTIVATED') NOT NULL DEFAULT 'PENDING_APPROVAL',
  `created_at` timestamp NOT NULL,
  `last_login_at` timestamp NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE (`email`)
) ENGINE=InnoDB;

CREATE TABLE `student_profiles` (
  `user_id` bigint NOT NULL,
  `major_id` int NOT NULL,
  `graduation_year` smallint NOT NULL,
  `career_interests` text NULL,
  PRIMARY KEY (`user_id`),
  INDEX `ix_student_discovery_major_year` (`major_id`, `graduation_year`)
) ENGINE=InnoDB;

CREATE TABLE `schools` (
  `school_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `city` varchar(100) NULL,
  `state` varchar(50) NULL,
  `is_active` boolean NOT NULL DEFAULT true,
  PRIMARY KEY (`school_id`),
  UNIQUE (`name`)
) ENGINE=InnoDB;

CREATE TABLE `academic_disciplines` (
  `discipline_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` boolean NOT NULL DEFAULT true,
  `merged_into_discipline_id` int NULL,
  PRIMARY KEY (`discipline_id`),
  UNIQUE (`name`),
  CONSTRAINT `ck_academic_disciplines_1` CHECK (merged_into_discipline_id IS NULL OR is_active = false)
) ENGINE=InnoDB;

CREATE TABLE `majors` (
  `major_id` int NOT NULL AUTO_INCREMENT,
  `discipline_id` int NOT NULL,
  `name` varchar(150) NOT NULL,
  `is_active` boolean NOT NULL DEFAULT true,
  `merged_into_major_id` int NULL,
  PRIMARY KEY (`major_id`),
  UNIQUE (`discipline_id`, `name`),
  CONSTRAINT `ck_majors_1` CHECK (merged_into_major_id IS NULL OR is_active = false)
) ENGINE=InnoDB;

CREATE TABLE `industries` (
  `industry_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` boolean NOT NULL DEFAULT true,
  `merged_into_industry_id` int NULL,
  PRIMARY KEY (`industry_id`),
  UNIQUE (`name`),
  CONSTRAINT `ck_industries_1` CHECK (merged_into_industry_id IS NULL OR is_active = false)
) ENGINE=InnoDB;

CREATE TABLE `skills` (
  `skill_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` boolean NOT NULL DEFAULT true,
  `merged_into_skill_id` int NULL,
  `created_at` timestamp NOT NULL,
  `parent_skill_id` int NULL,
  PRIMARY KEY (`skill_id`),
  UNIQUE (`name`),
  CONSTRAINT `ck_skills_1` CHECK (merged_into_skill_id IS NULL OR is_active = false)
) ENGINE=InnoDB;

CREATE TABLE `student_skills` (
  `student_user_id` bigint NOT NULL,
  `skill_id` int NOT NULL,
  `added_at` timestamp NOT NULL,
  PRIMARY KEY (`student_user_id`, `skill_id`)
) ENGINE=InnoDB;

CREATE TABLE `companies` (
  `company_id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `industry_id` int NOT NULL,
  `description` text NULL,
  `logo_url` varchar(500) NULL,
  `website_url` varchar(300) NULL,
  `culture_description` text NULL,
  `status` ENUM('PENDING', 'APPROVED', 'REJECTED', 'DEACTIVATED') NOT NULL DEFAULT 'PENDING',
  `approved_by_user_id` bigint NULL,
  `approved_at` timestamp NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB;

CREATE TABLE `company_locations` (
  `location_id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(50) NULL,
  `country` varchar(60) NOT NULL,
  `address_line` varchar(200) NULL,
  `is_headquarters` boolean NOT NULL DEFAULT false,
  PRIMARY KEY (`location_id`),
  UNIQUE (`company_id`, `location_id`)
) ENGINE=InnoDB;

CREATE TABLE `company_memberships` (
  `membership_id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `status` ENUM('PENDING', 'ACTIVE', 'REJECTED', 'REVOKED') NOT NULL DEFAULT 'PENDING',
  `requested_at` timestamp NOT NULL,
  `reviewed_by_user_id` bigint NULL,
  `reviewed_at` timestamp NULL,
  `ended_at` timestamp NULL,
  PRIMARY KEY (`membership_id`),
  UNIQUE (`company_id`, `user_id`)
) ENGINE=InnoDB;

CREATE TABLE `posts` (
  `post_id` bigint NOT NULL AUTO_INCREMENT,
  `author_user_id` bigint NOT NULL,
  `post_type` ENUM('PORTFOLIO', 'COMPANY') NOT NULL,
  `company_id` bigint NULL,
  `discipline_id` int NULL,
  `title` varchar(200) NOT NULL,
  `description` text NULL,
  `feed_visible` boolean NOT NULL DEFAULT true,
  `status` ENUM('ACTIVE', 'HIDDEN', 'REMOVED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL,
  `major_id` int NULL,
  `portfolio_visible` boolean NOT NULL DEFAULT true,
  `deleted_at` timestamp NULL,
  PRIMARY KEY (`post_id`),
  UNIQUE (`post_id`, `author_user_id`),
  UNIQUE (`post_id`, `company_id`),
  CONSTRAINT `ck_posts_1` CHECK (major_id IS NULL OR discipline_id IS NULL),
  CONSTRAINT `ck_posts_2` CHECK (post_type <> 'COMPANY' OR company_id IS NOT NULL),
  CONSTRAINT `ck_posts_3` CHECK ((status = 'REMOVED') = (deleted_at IS NOT NULL))
) ENGINE=InnoDB;

CREATE TABLE `post_media` (
  `media_id` bigint NOT NULL AUTO_INCREMENT,
  `post_id` bigint NOT NULL,
  `media_type` ENUM('VIDEO', 'IMAGE', 'AUDIO', 'DOCUMENT', 'OTHER') NOT NULL,
  `media_url` varchar(500) NOT NULL,
  `thumbnail_url` varchar(500) NULL,
  `duration_seconds` smallint NULL,
  `file_size_bytes` bigint NULL,
  `display_order` smallint NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`media_id`),
  UNIQUE (`post_id`, `display_order`),
  CONSTRAINT `ck_post_media_1` CHECK (display_order >= 1),
  CONSTRAINT `ck_post_media_2` CHECK (duration_seconds IS NULL OR duration_seconds > 0),
  CONSTRAINT `ck_post_media_3` CHECK (file_size_bytes IS NULL OR file_size_bytes > 0)
) ENGINE=InnoDB;

CREATE TABLE `post_skills` (
  `post_id` bigint NOT NULL,
  `skill_id` int NOT NULL,
  PRIMARY KEY (`post_id`, `skill_id`)
) ENGINE=InnoDB;

CREATE TABLE `collaboration_verifications` (
  `verification_id` bigint NOT NULL AUTO_INCREMENT,
  `post_id` bigint NOT NULL,
  `company_id` bigint NOT NULL,
  `collaboration_type` ENUM('INTERNSHIP', 'RESEARCH', 'SPONSORED_PROJECT', 'OTHER') NOT NULL,
  `status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
  `requested_at` timestamp NOT NULL,
  `reviewed_by_user_id` bigint NULL,
  `reviewed_at` timestamp NULL,
  `rejection_reason` varchar(500) NULL,
  `showcase_status` ENUM('NOT_SHOWCASED', 'SHOWCASED') NOT NULL DEFAULT 'NOT_SHOWCASED',
  `showcase_order` smallint NULL,
  `showcased_by_user_id` bigint NULL,
  `showcased_at` timestamp NULL,
  PRIMARY KEY (`verification_id`),
  UNIQUE (`post_id`),
  INDEX `ix_verified_post_lookup` (`status`, `post_id`),
  CONSTRAINT `ck_collaboration_verifications_1` CHECK (showcase_status <> 'SHOWCASED' OR status = 'APPROVED'),
  CONSTRAINT `ck_collaboration_verifications_2` CHECK (status = 'PENDING' OR (reviewed_by_user_id IS NOT NULL AND reviewed_at IS NOT NULL))
) ENGINE=InnoDB;

CREATE TABLE `user_follows` (
  `follower_user_id` bigint NOT NULL,
  `followed_user_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`follower_user_id`, `followed_user_id`),
  CONSTRAINT `ck_user_follows_1` CHECK (follower_user_id <> followed_user_id)
) ENGINE=InnoDB;

CREATE TABLE `post_likes` (
  `post_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`post_id`, `user_id`)
) ENGINE=InnoDB;

CREATE TABLE `post_comments` (
  `comment_id` bigint NOT NULL AUTO_INCREMENT,
  `post_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `body` text NOT NULL,
  `status` ENUM('ACTIVE', 'HIDDEN', 'REMOVED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL,
  `deleted_at` timestamp NULL,
  PRIMARY KEY (`comment_id`),
  CONSTRAINT `ck_post_comments_1` CHECK ((status = 'REMOVED') = (deleted_at IS NOT NULL))
) ENGINE=InnoDB;

CREATE TABLE `post_saves` (
  `post_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `saved_at` timestamp NOT NULL,
  PRIMARY KEY (`post_id`, `user_id`)
) ENGINE=InnoDB;

CREATE TABLE `post_shares` (
  `share_id` bigint NOT NULL AUTO_INCREMENT,
  `post_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `channel` varchar(40) NULL,
  `shared_at` timestamp NOT NULL,
  PRIMARY KEY (`share_id`)
) ENGINE=InnoDB;

CREATE TABLE `saved_companies` (
  `user_id` bigint NOT NULL,
  `company_id` bigint NOT NULL,
  `saved_at` timestamp NOT NULL,
  PRIMARY KEY (`user_id`, `company_id`)
) ENGINE=InnoDB;

CREATE TABLE `view_events` (
  `view_id` bigint NOT NULL AUTO_INCREMENT,
  `viewer_user_id` bigint NOT NULL,
  `post_id` bigint NULL,
  `company_id` bigint NULL,
  `job_id` bigint NULL,
  `viewed_at` timestamp NOT NULL,
  PRIMARY KEY (`view_id`),
  CONSTRAINT `ck_view_events_1` CHECK ((post_id IS NOT NULL) + (company_id IS NOT NULL) + (job_id IS NOT NULL) = 1)
) ENGINE=InnoDB;

CREATE TABLE `job_postings` (
  `job_id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `posted_by_user_id` bigint NOT NULL,
  `location_id` bigint NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `employment_type` ENUM('INTERNSHIP', 'FULL_TIME', 'PART_TIME', 'CONTRACT') NOT NULL,
  `is_remote` boolean NOT NULL DEFAULT false,
  `application_deadline` timestamp NULL,
  `status` ENUM('DRAFT', 'ACTIVE', 'EXPIRED', 'CLOSED', 'REMOVED') NOT NULL DEFAULT 'ACTIVE',
  `posted_at` timestamp NOT NULL,
  `updated_at` timestamp NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB;

CREATE TABLE `job_skills` (
  `job_id` bigint NOT NULL,
  `skill_id` int NOT NULL,
  `requirement_level` ENUM('REQUIRED', 'PREFERRED') NOT NULL,
  PRIMARY KEY (`job_id`, `skill_id`)
) ENGINE=InnoDB;

CREATE TABLE `job_disciplines` (
  `job_id` bigint NOT NULL,
  `discipline_id` int NOT NULL,
  PRIMARY KEY (`job_id`, `discipline_id`)
) ENGINE=InnoDB;

CREATE TABLE `application_statuses` (
  `status_id` smallint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `sort_order` smallint NOT NULL,
  `is_active` boolean NOT NULL DEFAULT true,
  PRIMARY KEY (`status_id`),
  UNIQUE (`name`)
) ENGINE=InnoDB;

CREATE TABLE `applications` (
  `application_id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `student_user_id` bigint NOT NULL,
  `status_id` smallint NOT NULL,
  `invitation_id` bigint NULL,
  `cover_note` text NULL,
  `submitted_at` timestamp NOT NULL,
  `status_updated_at` timestamp NOT NULL,
  `evidence_sealed_at` timestamp NULL,
  PRIMARY KEY (`application_id`),
  UNIQUE (`job_id`, `student_user_id`),
  UNIQUE (`application_id`, `student_user_id`),
  UNIQUE (`application_id`, `job_id`),
  UNIQUE (`invitation_id`)
) ENGINE=InnoDB;

CREATE TABLE `application_portfolio_posts` (
  `application_id` bigint NOT NULL,
  `post_id` bigint NOT NULL,
  `display_order` smallint NOT NULL,
  `student_user_id` bigint NOT NULL,
  `snapshot_id` bigint NOT NULL,
  PRIMARY KEY (`application_id`, `post_id`),
  UNIQUE (`application_id`, `display_order`),
  UNIQUE (`snapshot_id`),
  CONSTRAINT `ck_application_portfolio_posts_1` CHECK (display_order >= 1)
) ENGINE=InnoDB;

CREATE TABLE `application_status_history` (
  `history_id` bigint NOT NULL AUTO_INCREMENT,
  `application_id` bigint NOT NULL,
  `status_id` smallint NOT NULL,
  `changed_by_user_id` bigint NOT NULL,
  `note` text NULL,
  `changed_at` timestamp NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=InnoDB;

CREATE TABLE `job_invitations` (
  `invitation_id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `recruiter_user_id` bigint NOT NULL,
  `student_user_id` bigint NOT NULL,
  `message` text NULL,
  `status` ENUM('SENT', 'VIEWED', 'APPLIED', 'DECLINED', 'EXPIRED') NOT NULL DEFAULT 'SENT',
  `sent_at` timestamp NOT NULL,
  `responded_at` timestamp NULL,
  PRIMARY KEY (`invitation_id`),
  UNIQUE (`job_id`, `student_user_id`),
  UNIQUE (`invitation_id`, `job_id`, `student_user_id`)
) ENGINE=InnoDB;

CREATE TABLE `candidate_lists` (
  `list_id` bigint NOT NULL AUTO_INCREMENT,
  `recruiter_user_id` bigint NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`list_id`),
  UNIQUE (`recruiter_user_id`, `name`)
) ENGINE=InnoDB;

CREATE TABLE `candidate_list_items` (
  `list_id` bigint NOT NULL,
  `student_user_id` bigint NOT NULL,
  `added_at` timestamp NOT NULL,
  `note` varchar(500) NULL,
  PRIMARY KEY (`list_id`, `student_user_id`)
) ENGINE=InnoDB;

CREATE TABLE `conversations` (
  `conversation_id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NULL,
  `application_id` bigint NULL,
  `created_by_user_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`conversation_id`),
  CONSTRAINT `ck_conversations_1` CHECK (application_id IS NULL OR job_id IS NOT NULL)
) ENGINE=InnoDB;

CREATE TABLE `conversation_participants` (
  `conversation_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `joined_at` timestamp NOT NULL,
  `last_read_at` timestamp NULL,
  PRIMARY KEY (`conversation_id`, `user_id`)
) ENGINE=InnoDB;

CREATE TABLE `messages` (
  `message_id` bigint NOT NULL AUTO_INCREMENT,
  `conversation_id` bigint NOT NULL,
  `sender_user_id` bigint NOT NULL,
  `body` text NOT NULL,
  `sent_at` timestamp NOT NULL,
  `is_removed` boolean NOT NULL DEFAULT false,
  `deleted_at` timestamp NULL,
  PRIMARY KEY (`message_id`),
  CONSTRAINT `ck_messages_1` CHECK (is_removed IN (false, true) AND ((is_removed = true) = (deleted_at IS NOT NULL)))
) ENGINE=InnoDB;

CREATE TABLE `notifications` (
  `notification_id` bigint NOT NULL AUTO_INCREMENT,
  `recipient_user_id` bigint NOT NULL,
  `notification_type` ENUM('POST_LIKED', 'POST_COMMENTED', 'NEW_FOLLOWER', 'MESSAGE_RECEIVED', 'VERIFICATION_REQUESTED', 'VERIFICATION_DECIDED', 'APPLICATION_SUBMITTED', 'APPLICATION_STATUS_CHANGED', 'INVITATION_RECEIVED', 'MEMBERSHIP_REQUESTED', 'MEMBERSHIP_DECIDED', 'FEEDBACK_RECEIVED', 'RECOMMENDATION_RECEIVED', 'REPORT_UPDATE', 'SYSTEM') NOT NULL,
  `title` varchar(200) NOT NULL,
  `body` varchar(500) NULL,
  `is_read` boolean NOT NULL DEFAULT false,
  `read_at` timestamp NULL,
  `created_at` timestamp NOT NULL,
  `target_post_id` bigint NULL,
  `target_comment_id` bigint NULL,
  `target_user_id` bigint NULL,
  `target_company_id` bigint NULL,
  `target_job_id` bigint NULL,
  `target_application_id` bigint NULL,
  `target_invitation_id` bigint NULL,
  `target_verification_id` bigint NULL,
  `target_conversation_id` bigint NULL,
  `target_report_id` bigint NULL,
  `target_membership_id` bigint NULL,
  `target_assignment_id` bigint NULL,
  PRIMARY KEY (`notification_id`),
  CONSTRAINT `ck_notifications_1` CHECK ((target_post_id IS NOT NULL) + (target_comment_id IS NOT NULL) + (target_user_id IS NOT NULL) + (target_company_id IS NOT NULL) + (target_job_id IS NOT NULL) + (target_application_id IS NOT NULL) + (target_invitation_id IS NOT NULL) + (target_verification_id IS NOT NULL) + (target_conversation_id IS NOT NULL) + (target_report_id IS NOT NULL) + (target_membership_id IS NOT NULL) + (target_assignment_id IS NOT NULL) <= 1),
  CONSTRAINT `ck_notifications_2` CHECK ((is_read = false AND read_at IS NULL) OR (is_read = true AND read_at IS NOT NULL))
) ENGINE=InnoDB;

CREATE TABLE `advisor_student_assignments` (
  `assignment_id` bigint NOT NULL AUTO_INCREMENT,
  `advisor_user_id` bigint NOT NULL,
  `student_user_id` bigint NOT NULL,
  `assigned_by_user_id` bigint NULL,
  `source` ENUM('ADMIN_ASSIGNED', 'STUDENT_AUTHORIZED') NOT NULL,
  `status` ENUM('PENDING', 'ACTIVE', 'REVOKED') NOT NULL DEFAULT 'PENDING',
  `requested_at` timestamp NOT NULL,
  `authorized_at` timestamp NULL,
  `ended_at` timestamp NULL,
  PRIMARY KEY (`assignment_id`),
  UNIQUE (`advisor_user_id`, `student_user_id`),
  UNIQUE (`assignment_id`, `student_user_id`)
) ENGINE=InnoDB;

CREATE TABLE `portfolio_feedback` (
  `feedback_id` bigint NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint NOT NULL,
  `post_id` bigint NULL,
  `feedback_type` ENUM('GENERAL', 'DESCRIPTION', 'SKILL_TAGS', 'MEDIA', 'COMPLETENESS', 'RECOMMENDED_CONTENT') NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL,
  `student_user_id` bigint NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB;

CREATE TABLE `opportunity_recommendations` (
  `recommendation_id` bigint NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint NOT NULL,
  `job_id` bigint NOT NULL,
  `message` text NULL,
  `status` ENUM('SENT', 'VIEWED', 'APPLIED', 'DISMISSED') NOT NULL DEFAULT 'SENT',
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`recommendation_id`),
  UNIQUE (`assignment_id`, `job_id`)
) ENGINE=InnoDB;

CREATE TABLE `reports` (
  `report_id` bigint NOT NULL AUTO_INCREMENT,
  `reporter_user_id` bigint NOT NULL,
  `category` ENUM('HARASSMENT', 'FRAUDULENT_RECRUITER', 'FALSE_COMPANY_CLAIM', 'INAPPROPRIATE_CONTENT', 'FRAUDULENT_JOB', 'OTHER') NOT NULL,
  `description` text NULL,
  `status` ENUM('OPEN', 'UNDER_REVIEW', 'RESOLVED', 'DISMISSED') NOT NULL DEFAULT 'OPEN',
  `target_post_id` bigint NULL,
  `target_comment_id` bigint NULL,
  `target_user_id` bigint NULL,
  `target_message_id` bigint NULL,
  `target_job_id` bigint NULL,
  `target_company_id` bigint NULL,
  `created_at` timestamp NOT NULL,
  `resolved_at` timestamp NULL,
  PRIMARY KEY (`report_id`),
  CONSTRAINT `ck_reports_1` CHECK ((target_post_id IS NOT NULL) + (target_comment_id IS NOT NULL) + (target_user_id IS NOT NULL) + (target_message_id IS NOT NULL) + (target_job_id IS NOT NULL) + (target_company_id IS NOT NULL) = 1)
) ENGINE=InnoDB;

CREATE TABLE `moderation_actions` (
  `action_id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint NOT NULL,
  `admin_user_id` bigint NOT NULL,
  `action_type` ENUM('NO_ACTION', 'WARNING', 'CONTENT_HIDDEN', 'CONTENT_REMOVED', 'ACCOUNT_SUSPENDED', 'ACCOUNT_BANNED', 'COMPANY_DEACTIVATED', 'JOB_REMOVED') NOT NULL,
  `notes` text NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=InnoDB;

CREATE TABLE `system_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(500) NOT NULL,
  `description` varchar(255) NULL,
  `updated_by_user_id` bigint NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB;

CREATE TABLE `application_materials` (
  `material_id` bigint NOT NULL AUTO_INCREMENT,
  `application_id` bigint NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `media_type` varchar(100) NOT NULL,
  `storage_url` varchar(500) NOT NULL,
  `uploaded_at` timestamp NOT NULL,
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB;

CREATE TABLE `application_notes` (
  `note_id` bigint NOT NULL AUTO_INCREMENT,
  `application_id` bigint NOT NULL,
  `recruiter_user_id` bigint NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL,
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB;

CREATE TABLE `account_reviews` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `subject_user_id` bigint NOT NULL,
  `reviewed_by_user_id` bigint NOT NULL,
  `decision` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL,
  `reason` text NULL,
  `reviewed_at` timestamp NOT NULL,
  PRIMARY KEY (`review_id`),
  CONSTRAINT `ck_account_reviews_1` CHECK (decision <> 'PENDING'),
  CONSTRAINT `ck_account_reviews_2` CHECK (subject_user_id <> reviewed_by_user_id)
) ENGINE=InnoDB;

CREATE TABLE `skill_aliases` (
  `alias_id` int NOT NULL AUTO_INCREMENT,
  `skill_id` int NOT NULL,
  `alias` varchar(100) NOT NULL,
  `is_active` boolean NOT NULL,
  PRIMARY KEY (`alias_id`),
  UNIQUE (`alias`)
) ENGINE=InnoDB;

CREATE TABLE `verification_transitions` (
  `from_status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL,
  `to_status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL,
  PRIMARY KEY (`from_status`, `to_status`),
  CONSTRAINT `ck_verification_transitions_1` CHECK (from_status <> to_status)
) ENGINE=InnoDB;

CREATE TABLE `collaboration_verification_history` (
  `history_id` bigint NOT NULL AUTO_INCREMENT,
  `verification_id` bigint NOT NULL,
  `from_status` ENUM('PENDING', 'APPROVED', 'REJECTED') NULL,
  `to_status` ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL,
  `changed_by_user_id` bigint NOT NULL,
  `changed_at` timestamp NOT NULL,
  `reason` text NULL,
  PRIMARY KEY (`history_id`),
  CONSTRAINT `ck_collaboration_verification_history_1` CHECK (from_status IS NOT NULL OR to_status = 'PENDING')
) ENGINE=InnoDB;

CREATE TABLE `application_post_snapshots` (
  `snapshot_id` bigint NOT NULL AUTO_INCREMENT,
  `application_id` bigint NOT NULL,
  `source_post_id` bigint NOT NULL,
  `source_author_user_id` bigint NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NULL,
  `verification_status_at_capture` ENUM('PENDING', 'APPROVED', 'REJECTED') NULL,
  `captured_at` timestamp NOT NULL,
  `sealed_at` timestamp NULL,
  PRIMARY KEY (`snapshot_id`),
  UNIQUE (`application_id`, `source_post_id`),
  UNIQUE (`snapshot_id`, `application_id`, `source_post_id`, `source_author_user_id`)
) ENGINE=InnoDB;

CREATE TABLE `application_snapshot_media` (
  `snapshot_media_id` bigint NOT NULL AUTO_INCREMENT,
  `snapshot_id` bigint NOT NULL,
  `source_media_id` bigint NOT NULL,
  `media_type` ENUM('VIDEO', 'IMAGE', 'AUDIO', 'DOCUMENT', 'OTHER') NOT NULL,
  `immutable_storage_key` varchar(500) NOT NULL,
  `content_sha256` char(64) NOT NULL,
  `display_order` smallint NOT NULL,
  PRIMARY KEY (`snapshot_media_id`),
  UNIQUE (`snapshot_id`, `display_order`),
  CONSTRAINT `ck_application_snapshot_media_1` CHECK (display_order >= 1),
  CONSTRAINT `ck_application_snapshot_media_2` CHECK (CHAR_LENGTH(content_sha256) = 64)
) ENGINE=InnoDB;

CREATE TABLE `application_snapshot_skills` (
  `snapshot_id` bigint NOT NULL,
  `skill_id_at_capture` int NOT NULL,
  `skill_name_at_capture` varchar(100) NOT NULL,
  PRIMARY KEY (`snapshot_id`, `skill_id_at_capture`)
) ENGINE=InnoDB;

ALTER TABLE `role_permissions` ADD CONSTRAINT `fk_R001` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `role_permissions` ADD CONSTRAINT `fk_R002` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`permission_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `users` ADD CONSTRAINT `fk_R003` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `users` ADD CONSTRAINT `fk_R004` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `student_profiles` ADD CONSTRAINT `fk_R005` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `student_profiles` ADD CONSTRAINT `fk_R006` FOREIGN KEY (`major_id`) REFERENCES `majors` (`major_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `academic_disciplines` ADD CONSTRAINT `fk_R007` FOREIGN KEY (`merged_into_discipline_id`) REFERENCES `academic_disciplines` (`discipline_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `majors` ADD CONSTRAINT `fk_R008` FOREIGN KEY (`discipline_id`) REFERENCES `academic_disciplines` (`discipline_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `majors` ADD CONSTRAINT `fk_R009` FOREIGN KEY (`merged_into_major_id`) REFERENCES `majors` (`major_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `industries` ADD CONSTRAINT `fk_R010` FOREIGN KEY (`merged_into_industry_id`) REFERENCES `industries` (`industry_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `skills` ADD CONSTRAINT `fk_R011` FOREIGN KEY (`merged_into_skill_id`) REFERENCES `skills` (`skill_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `student_skills` ADD CONSTRAINT `fk_R012` FOREIGN KEY (`student_user_id`) REFERENCES `student_profiles` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `student_skills` ADD CONSTRAINT `fk_R013` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`skill_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `companies` ADD CONSTRAINT `fk_R014` FOREIGN KEY (`industry_id`) REFERENCES `industries` (`industry_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `companies` ADD CONSTRAINT `fk_R015` FOREIGN KEY (`approved_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `company_locations` ADD CONSTRAINT `fk_R016` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `company_memberships` ADD CONSTRAINT `fk_R017` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `company_memberships` ADD CONSTRAINT `fk_R018` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `company_memberships` ADD CONSTRAINT `fk_R019` FOREIGN KEY (`reviewed_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `posts` ADD CONSTRAINT `fk_R020` FOREIGN KEY (`author_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `posts` ADD CONSTRAINT `fk_R021` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `posts` ADD CONSTRAINT `fk_R022` FOREIGN KEY (`discipline_id`) REFERENCES `academic_disciplines` (`discipline_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `posts` ADD CONSTRAINT `fk_R023` FOREIGN KEY (`major_id`) REFERENCES `majors` (`major_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_media` ADD CONSTRAINT `fk_R024` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_skills` ADD CONSTRAINT `fk_R025` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_skills` ADD CONSTRAINT `fk_R026` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`skill_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `collaboration_verifications` ADD CONSTRAINT `fk_R027` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `collaboration_verifications` ADD CONSTRAINT `fk_R028` FOREIGN KEY (`reviewed_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `collaboration_verifications` ADD CONSTRAINT `fk_R029` FOREIGN KEY (`showcased_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `user_follows` ADD CONSTRAINT `fk_R030` FOREIGN KEY (`follower_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `user_follows` ADD CONSTRAINT `fk_R031` FOREIGN KEY (`followed_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_likes` ADD CONSTRAINT `fk_R032` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_likes` ADD CONSTRAINT `fk_R033` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_comments` ADD CONSTRAINT `fk_R034` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_comments` ADD CONSTRAINT `fk_R035` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_saves` ADD CONSTRAINT `fk_R036` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_saves` ADD CONSTRAINT `fk_R037` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_shares` ADD CONSTRAINT `fk_R038` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `post_shares` ADD CONSTRAINT `fk_R039` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `saved_companies` ADD CONSTRAINT `fk_R040` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `saved_companies` ADD CONSTRAINT `fk_R041` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `view_events` ADD CONSTRAINT `fk_R042` FOREIGN KEY (`viewer_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `view_events` ADD CONSTRAINT `fk_R043` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `view_events` ADD CONSTRAINT `fk_R044` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `view_events` ADD CONSTRAINT `fk_R045` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_postings` ADD CONSTRAINT `fk_R046` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_postings` ADD CONSTRAINT `fk_R047` FOREIGN KEY (`posted_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_skills` ADD CONSTRAINT `fk_R048` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_skills` ADD CONSTRAINT `fk_R049` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`skill_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_disciplines` ADD CONSTRAINT `fk_R050` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_disciplines` ADD CONSTRAINT `fk_R051` FOREIGN KEY (`discipline_id`) REFERENCES `academic_disciplines` (`discipline_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `applications` ADD CONSTRAINT `fk_R052` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `applications` ADD CONSTRAINT `fk_R053` FOREIGN KEY (`student_user_id`) REFERENCES `student_profiles` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `applications` ADD CONSTRAINT `fk_R054` FOREIGN KEY (`status_id`) REFERENCES `application_statuses` (`status_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_status_history` ADD CONSTRAINT `fk_R055` FOREIGN KEY (`application_id`) REFERENCES `applications` (`application_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_status_history` ADD CONSTRAINT `fk_R056` FOREIGN KEY (`status_id`) REFERENCES `application_statuses` (`status_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_status_history` ADD CONSTRAINT `fk_R057` FOREIGN KEY (`changed_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_invitations` ADD CONSTRAINT `fk_R058` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_invitations` ADD CONSTRAINT `fk_R059` FOREIGN KEY (`recruiter_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_invitations` ADD CONSTRAINT `fk_R060` FOREIGN KEY (`student_user_id`) REFERENCES `student_profiles` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `candidate_lists` ADD CONSTRAINT `fk_R061` FOREIGN KEY (`recruiter_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `candidate_list_items` ADD CONSTRAINT `fk_R062` FOREIGN KEY (`list_id`) REFERENCES `candidate_lists` (`list_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `candidate_list_items` ADD CONSTRAINT `fk_R063` FOREIGN KEY (`student_user_id`) REFERENCES `student_profiles` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `conversations` ADD CONSTRAINT `fk_R064` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `conversation_participants` ADD CONSTRAINT `fk_R065` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`conversation_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `conversation_participants` ADD CONSTRAINT `fk_R066` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R067` FOREIGN KEY (`recipient_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R068` FOREIGN KEY (`target_post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R069` FOREIGN KEY (`target_comment_id`) REFERENCES `post_comments` (`comment_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R070` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R071` FOREIGN KEY (`target_company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R072` FOREIGN KEY (`target_job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R073` FOREIGN KEY (`target_application_id`) REFERENCES `applications` (`application_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R074` FOREIGN KEY (`target_invitation_id`) REFERENCES `job_invitations` (`invitation_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R075` FOREIGN KEY (`target_verification_id`) REFERENCES `collaboration_verifications` (`verification_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R076` FOREIGN KEY (`target_conversation_id`) REFERENCES `conversations` (`conversation_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R077` FOREIGN KEY (`target_report_id`) REFERENCES `reports` (`report_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R078` FOREIGN KEY (`target_membership_id`) REFERENCES `company_memberships` (`membership_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_R079` FOREIGN KEY (`target_assignment_id`) REFERENCES `advisor_student_assignments` (`assignment_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `advisor_student_assignments` ADD CONSTRAINT `fk_R080` FOREIGN KEY (`advisor_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `advisor_student_assignments` ADD CONSTRAINT `fk_R081` FOREIGN KEY (`student_user_id`) REFERENCES `student_profiles` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `advisor_student_assignments` ADD CONSTRAINT `fk_R082` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `opportunity_recommendations` ADD CONSTRAINT `fk_R083` FOREIGN KEY (`assignment_id`) REFERENCES `advisor_student_assignments` (`assignment_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `opportunity_recommendations` ADD CONSTRAINT `fk_R084` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `reports` ADD CONSTRAINT `fk_R085` FOREIGN KEY (`reporter_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `reports` ADD CONSTRAINT `fk_R086` FOREIGN KEY (`target_post_id`) REFERENCES `posts` (`post_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `reports` ADD CONSTRAINT `fk_R087` FOREIGN KEY (`target_comment_id`) REFERENCES `post_comments` (`comment_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `reports` ADD CONSTRAINT `fk_R088` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `reports` ADD CONSTRAINT `fk_R089` FOREIGN KEY (`target_message_id`) REFERENCES `messages` (`message_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `reports` ADD CONSTRAINT `fk_R090` FOREIGN KEY (`target_job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `reports` ADD CONSTRAINT `fk_R091` FOREIGN KEY (`target_company_id`) REFERENCES `companies` (`company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `moderation_actions` ADD CONSTRAINT `fk_R092` FOREIGN KEY (`report_id`) REFERENCES `reports` (`report_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `moderation_actions` ADD CONSTRAINT `fk_R093` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `system_settings` ADD CONSTRAINT `fk_R094` FOREIGN KEY (`updated_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_materials` ADD CONSTRAINT `fk_R095` FOREIGN KEY (`application_id`) REFERENCES `applications` (`application_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_notes` ADD CONSTRAINT `fk_R096` FOREIGN KEY (`application_id`) REFERENCES `applications` (`application_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_notes` ADD CONSTRAINT `fk_R097` FOREIGN KEY (`recruiter_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `account_reviews` ADD CONSTRAINT `fk_R098` FOREIGN KEY (`subject_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `account_reviews` ADD CONSTRAINT `fk_R099` FOREIGN KEY (`reviewed_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `messages` ADD CONSTRAINT `fk_R100` FOREIGN KEY (`conversation_id`, `sender_user_id`) REFERENCES `conversation_participants` (`conversation_id`, `user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `job_postings` ADD CONSTRAINT `fk_R101` FOREIGN KEY (`company_id`, `location_id`) REFERENCES `company_locations` (`company_id`, `location_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `collaboration_verifications` ADD CONSTRAINT `fk_R102` FOREIGN KEY (`post_id`, `company_id`) REFERENCES `posts` (`post_id`, `company_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_portfolio_posts` ADD CONSTRAINT `fk_R103` FOREIGN KEY (`application_id`, `student_user_id`) REFERENCES `applications` (`application_id`, `student_user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_portfolio_posts` ADD CONSTRAINT `fk_R104` FOREIGN KEY (`post_id`, `student_user_id`) REFERENCES `posts` (`post_id`, `author_user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `applications` ADD CONSTRAINT `fk_R105` FOREIGN KEY (`invitation_id`, `job_id`, `student_user_id`) REFERENCES `job_invitations` (`invitation_id`, `job_id`, `student_user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `portfolio_feedback` ADD CONSTRAINT `fk_R106` FOREIGN KEY (`assignment_id`, `student_user_id`) REFERENCES `advisor_student_assignments` (`assignment_id`, `student_user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `portfolio_feedback` ADD CONSTRAINT `fk_R107` FOREIGN KEY (`post_id`, `student_user_id`) REFERENCES `posts` (`post_id`, `author_user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `conversations` ADD CONSTRAINT `fk_R108` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `conversations` ADD CONSTRAINT `fk_R109` FOREIGN KEY (`application_id`, `job_id`) REFERENCES `applications` (`application_id`, `job_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `skills` ADD CONSTRAINT `fk_R110` FOREIGN KEY (`parent_skill_id`) REFERENCES `skills` (`skill_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `skill_aliases` ADD CONSTRAINT `fk_R111` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`skill_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_post_snapshots` ADD CONSTRAINT `fk_R112` FOREIGN KEY (`application_id`, `source_author_user_id`) REFERENCES `applications` (`application_id`, `student_user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_snapshot_media` ADD CONSTRAINT `fk_R113` FOREIGN KEY (`snapshot_id`) REFERENCES `application_post_snapshots` (`snapshot_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_snapshot_skills` ADD CONSTRAINT `fk_R114` FOREIGN KEY (`snapshot_id`) REFERENCES `application_post_snapshots` (`snapshot_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `application_portfolio_posts` ADD CONSTRAINT `fk_R115` FOREIGN KEY (`snapshot_id`, `application_id`, `post_id`, `student_user_id`) REFERENCES `application_post_snapshots` (`snapshot_id`, `application_id`, `source_post_id`, `source_author_user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `collaboration_verification_history` ADD CONSTRAINT `fk_R116` FOREIGN KEY (`verification_id`) REFERENCES `collaboration_verifications` (`verification_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `collaboration_verification_history` ADD CONSTRAINT `fk_R117` FOREIGN KEY (`changed_by_user_id`) REFERENCES `users` (`user_id`) ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE `collaboration_verification_history` ADD CONSTRAINT `fk_R118` FOREIGN KEY (`from_status`, `to_status`) REFERENCES `verification_transitions` (`from_status`, `to_status`) ON UPDATE RESTRICT ON DELETE RESTRICT;

INSERT INTO verification_transitions (from_status,to_status) VALUES ('PENDING','APPROVED'),('PENDING','REJECTED'),('APPROVED','PENDING'),('REJECTED','PENDING');

DELIMITER $$

CREATE TRIGGER `snapshot_before_insert` BEFORE INSERT ON `application_post_snapshots` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; SELECT evidence_sealed_at INTO done FROM applications WHERE application_id=NEW.application_id FOR UPDATE; IF done IS NOT NULL OR NEW.sealed_at IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `snapshot_before_update` BEFORE UPDATE ON `application_post_snapshots` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; DECLARE any_media BIGINT DEFAULT NULL; IF OLD.sealed_at IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; SELECT evidence_sealed_at INTO done FROM applications WHERE application_id=NEW.application_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; IF NEW.sealed_at IS NOT NULL THEN SELECT snapshot_media_id INTO any_media FROM application_snapshot_media WHERE snapshot_id=OLD.snapshot_id LIMIT 1 FOR UPDATE; IF any_media IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Capture requires media before sealing'; END IF; END IF; END$$

CREATE TRIGGER `snapshot_before_delete` BEFORE DELETE ON `application_post_snapshots` FOR EACH ROW BEGIN IF OLD.sealed_at IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `application_snapshot_media_insert` BEFORE INSERT ON `application_snapshot_media` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=NEW.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `application_snapshot_media_update` BEFORE UPDATE ON `application_snapshot_media` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=OLD.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=NEW.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `application_snapshot_media_delete` BEFORE DELETE ON `application_snapshot_media` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=OLD.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `application_snapshot_skills_insert` BEFORE INSERT ON `application_snapshot_skills` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=NEW.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `application_snapshot_skills_update` BEFORE UPDATE ON `application_snapshot_skills` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=OLD.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=NEW.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `application_snapshot_skills_delete` BEFORE DELETE ON `application_snapshot_skills` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; SELECT sealed_at INTO done FROM application_post_snapshots WHERE snapshot_id=OLD.snapshot_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `attachment_insert` BEFORE INSERT ON `application_portfolio_posts` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; DECLARE captured TIMESTAMP; SELECT evidence_sealed_at INTO done FROM applications WHERE application_id=NEW.application_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; SELECT evidence_sealed_at INTO done FROM applications WHERE application_id=NEW.application_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; SELECT sealed_at INTO captured FROM application_post_snapshots WHERE snapshot_id=NEW.snapshot_id FOR UPDATE; IF captured IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Attachment requires a sealed snapshot'; END IF; END$$

CREATE TRIGGER `attachment_update` BEFORE UPDATE ON `application_portfolio_posts` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; DECLARE captured TIMESTAMP; SELECT evidence_sealed_at INTO done FROM applications WHERE application_id=OLD.application_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; SELECT evidence_sealed_at INTO done FROM applications WHERE application_id=NEW.application_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; SELECT sealed_at INTO captured FROM application_post_snapshots WHERE snapshot_id=NEW.snapshot_id FOR UPDATE; IF captured IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Attachment requires a sealed snapshot'; END IF; END$$

CREATE TRIGGER `attachment_delete` BEFORE DELETE ON `application_portfolio_posts` FOR EACH ROW BEGIN DECLARE done TIMESTAMP; DECLARE captured TIMESTAMP; SELECT evidence_sealed_at INTO done FROM applications WHERE application_id=OLD.application_id FOR UPDATE; IF done IS NOT NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; END$$

CREATE TRIGGER `application_evidence_seal` BEFORE UPDATE ON `applications` FOR EACH ROW BEGIN DECLARE attached BIGINT DEFAULT NULL; IF OLD.evidence_sealed_at IS NOT NULL AND (NOT (NEW.evidence_sealed_at <=> OLD.evidence_sealed_at) OR NEW.application_id <> OLD.application_id OR NEW.student_user_id <> OLD.student_user_id OR NEW.job_id <> OLD.job_id) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Version B sealed evidence is immutable'; END IF; IF OLD.evidence_sealed_at IS NULL AND NEW.evidence_sealed_at IS NOT NULL THEN SELECT post_id INTO attached FROM application_portfolio_posts WHERE application_id=OLD.application_id LIMIT 1 FOR UPDATE; IF attached IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Application sealing requires portfolio evidence'; END IF; END IF; END$$

CREATE TRIGGER `append_only_collaboration_verification_history_update` BEFORE UPDATE ON `collaboration_verification_history` FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Append-only Version B audit event'; END$$

CREATE TRIGGER `append_only_collaboration_verification_history_delete` BEFORE DELETE ON `collaboration_verification_history` FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Append-only Version B audit event'; END$$

CREATE TRIGGER `append_only_moderation_actions_update` BEFORE UPDATE ON `moderation_actions` FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Append-only Version B audit event'; END$$

CREATE TRIGGER `append_only_moderation_actions_delete` BEFORE DELETE ON `moderation_actions` FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Append-only Version B audit event'; END$$

DELIMITER ;

ALTER TABLE moderation_actions ADD CONSTRAINT ck_moderation_action_reason CHECK (action_type = 'NO_ACTION' OR CHAR_LENGTH(TRIM(COALESCE(notes, ''))) > 0);

-- Parent creation cannot bypass evidence completion by starting already sealed.
DELIMITER $$
CREATE TRIGGER application_before_insert BEFORE INSERT ON applications FOR EACH ROW
BEGIN
  IF NEW.evidence_sealed_at IS NOT NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Create application unsealed; capture evidence before sealing';
  END IF;
END$$
DELIMITER ;
