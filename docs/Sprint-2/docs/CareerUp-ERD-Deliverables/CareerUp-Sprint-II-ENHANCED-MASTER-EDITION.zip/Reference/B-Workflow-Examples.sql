-- EXPERIMENTAL B WORKFLOW TEMPLATE. NOT EXECUTED.
-- Requires an existing authorized applicant, owned post, and NEW unsealed application.
-- Do not run against the illustrative final-state application 10001, which is already sealed.
-- The application must first copy/pin the media bytes to a versioned object and verify its hash.
-- Set @application_id, @post_id, @immutable_key, @sha256, @source_media_id and @media_type.
-- All source editing/capture workflows must follow the documented parent-locking protocol.
START TRANSACTION;
SELECT application_id FROM applications WHERE application_id=@application_id FOR UPDATE;
SELECT post_id FROM posts WHERE post_id=@post_id FOR UPDATE;

INSERT INTO application_post_snapshots
 (application_id,source_post_id,source_author_user_id,title,description,
  verification_status_at_capture,captured_at,sealed_at)
SELECT a.application_id,p.post_id,p.author_user_id,p.title,p.description,v.status,
       CURRENT_TIMESTAMP,NULL
FROM applications a JOIN posts p ON p.author_user_id=a.student_user_id
LEFT JOIN collaboration_verifications v ON v.post_id=p.post_id
WHERE a.application_id=@application_id AND p.post_id=@post_id
  AND a.evidence_sealed_at IS NULL AND p.post_type='PORTFOLIO' AND p.status='ACTIVE';
-- Application must require exactly one inserted snapshot before proceeding.
SET @snapshot_id=LAST_INSERT_ID();

INSERT INTO application_snapshot_media
 (snapshot_id,source_media_id,media_type,immutable_storage_key,content_sha256,display_order)
VALUES (@snapshot_id,@source_media_id,@media_type,@immutable_key,@sha256,1);
-- Repeat for all captured, validated files; the key/hash must describe retained exact bytes.
INSERT INTO application_snapshot_skills(snapshot_id,skill_id_at_capture,skill_name_at_capture)
SELECT @snapshot_id,s.skill_id,s.name FROM post_skills ps JOIN skills s ON s.skill_id=ps.skill_id
WHERE ps.post_id=@post_id AND s.is_active=true;

UPDATE application_post_snapshots SET sealed_at=CURRENT_TIMESTAMP WHERE snapshot_id=@snapshot_id;
INSERT INTO application_portfolio_posts(application_id,post_id,student_user_id,display_order,snapshot_id)
SELECT a.application_id,@post_id,a.student_user_id,1,@snapshot_id
FROM applications a WHERE a.application_id=@application_id;
-- Repeat complete snapshot/attachment capture for any other selected posts before sealing.
UPDATE applications SET evidence_sealed_at=CURRENT_TIMESTAMP WHERE application_id=@application_id;
-- Insert initial status history/required notifications in this same submission transaction.
-- Application must validate authorization, job eligibility, successful row counts and complete evidence.
COMMIT;

-- VERIFICATION DECISION: planned authorization/transaction sequence, not a new boolean flag.
-- Lock the request and verify current state, role, active company membership and company match.
-- Insert history using the actual old status and an allowed new status; update the current request
-- and decision reviewer/time atomically. Handle the initial null->PENDING history event separately.

-- MODERATION: lock target; authorize Administrator; create/refer to a report; update removed state
-- with deleted_at; insert moderation_actions with actor and a nonblank reason in the same transaction.
-- The SQL triggers protect audit rows but do not automatically generate an audit for arbitrary SQL.
