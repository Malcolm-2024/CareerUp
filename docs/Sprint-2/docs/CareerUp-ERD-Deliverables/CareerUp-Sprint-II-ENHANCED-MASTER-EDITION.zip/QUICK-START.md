# Master ERD edition

1. Extract the entire ZIP into a new folder. Open START-HERE.html.
2. The first seven cards open complete chapter master ERDs. The eighth card starts the full presentation with its detailed relationship steps.
3. Click Chapter Master ERDs in the sidebar or chapter controls to choose among all seven main diagrams.
4. Seven Main ERDs Only / Present the Seven Master ERDs runs just the seven complete diagrams, then a short summary. Next never opens the smaller relationship diagrams on this route.
5. Use the local diagram, Main master ERD, Whole activity on master, or Steps on master as needed. Fit current step, Fit full diagram and Reset view work inside the viewer.
6. For private notes, open Private presenter from the audience page. Put the audience on the projector and notes on the laptop using Extend displays. Check synchronization before class.
7. If synchronization is restricted, control the audience directly and read Presenter/SEVEN-MASTER-SCRIPTS.html or Presenter/FULL-SPEAKING-NOTES.html separately.

The scripts use short read-aloud explanations; exact keys and constraints remain in the reference. The competition's core script is approximately 533 words in A, with version-specific B wording. This is a design presentation, not a claim of a deployed application.

Live browser rendering and real two-window synchronization remain unverified because local-file browser access is blocked in this environment. Node/DOM-stub checks are not browser tests.
