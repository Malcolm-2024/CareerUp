# CareerUp unresolved business-rule review

**Recommendations only — not team-approved policies.** No schema, state, settings, example records or competition walkthrough was changed. This reviews all 25 unresolved entries in the 41-rule register. Existing requirements, current audited assumptions and suggested service policies are separated below.

No new tables are recommended. The checklist consolidates decisions with user-visible meaning; minor implementation follow-ups remain separate. Current PK/FK/UQ/NOT NULL/CHECK declarations are authoritative even while policies are pending.

## BR01 — Accounts select a supported role

Original unresolved question: Confirm whether one account may hold multiple roles.

**Existing requirement:** FRD defines five distinct account types and role-specific permissions; it does not demand multiple roles on one account.

**Current design / assumption:** One required users.role_id; one account has one stored role.

**Recommendation — pending approval:** Keep one role per account and multiple company memberships where needed. Defer simultaneous multi-role accounts.

**Conflict / scope check:** No conflict identified. Do not claim the FRD expressly forbids multiple roles.

**Database impact:** No DBML change. Simultaneous multi-role accounts would require a separate schema proposal.

**Approval classification:** Team approval of the retained account model. See checklist 1.

## BR02 — Secure sign-in uses account credentials and effective access state

Original unresolved question: Choose email normalization/collation and session policy.

**Existing requirement:** FRD requires valid credentials and secure sign-in/sign-out.

**Current design / assumption:** Email is unique under the future physical collation; no persistent session entity or normalization CHECK is declared.

**Recommendation — pending approval:** Trim surrounding email whitespace, apply one documented case-insensitive account-email comparison policy and matching physical uniqueness configuration; preserve password case. Use standard secure password hashing and session invalidation without inventing a sessions table. Keep detailed timeout choices for implementation review.

**Conflict / scope check:** FRD does not specify email case equivalence or timeout values. These remain proposed implementation choices.

**Database impact:** No new table/field. Physical email collation/index behavior must be checked during implementation.

**Approval classification:** Engineering follow-up; no additional Sprint II schema approval. A different identity-equivalence policy should be reviewed by the team.

## BR03 — Role-appropriate profiles share account identity

Original unresolved question: Confirm whether incomplete registration needs a draft profile.

**Existing requirement:** FRD lists major and graduation year among profile information but does not explicitly require a draft registration feature.

**Current design / assumption:** student_profiles.major_id and graduation_year are NOT NULL; users.school_id is optional.

**Recommendation — pending approval:** Require major and graduation year before committing a Student registration/profile transaction; allow optional school. Keep incomplete form values outside persistent student_profiles.

**Conflict / scope check:** No conflict identified, but mandatory completion is an audited design assumption rather than literal FRD wording.

**Database impact:** No DBML change. Persisting a profile without those required values would require a separate change proposal.

**Approval classification:** Team approval of registration-completion expectations. See checklist 2.

## BR04 — Account approval decisions are attributable

Original unresolved question: Define which roles require approval and allowed state transitions.

**Existing requirement:** FRD allows additional approval for employer/advisor accounts and gives Administrators account management.

**Current design / assumption:** users status enum and attributable account_reviews; review CHECK prevents PENDING decisions and self-review.

**Recommendation — pending approval:** Propose automatic ACTIVE Student registration after validation, Administrator approval for Recruiter, Company Representative and Advisor accounts, and system-created Administrators. Keep unapproved accounts PENDING_APPROVAL. Restrict suspension, ban, deactivation and restoration to Administrators; retain review/action evidence.

**Conflict / scope check:** FRD says employer/advisor accounts may require approval; making it mandatory is a proposed policy, not an already-approved requirement.

**Database impact:** No schema change; service state transitions and review rows only.

**Approval classification:** Team must approve the account approval chain. See checklist 3.

## BR05 — Companies have official information and administrative approval

Original unresolved question: Define approval evidence, lifecycle transitions and whether a single headquarters is required.

**Existing requirement:** FRD assigns company approval/deactivation to Administrators and company-profile management to Representatives.

**Current design / assumption:** Company status plus optional approval actor/time; repeating locations and unconstrained headquarters flags.

**Recommendation — pending approval:** Administrators approve companies; record approver/time atomically when APPROVED and use DEACTIVATED for inactive companies. Do not put rejection into approval metadata. If headquarters is selected, allow at most one through service validation; multiple ordinary locations remain allowed. Retain current state rather than add company-approval history.

**Conflict / scope check:** No conflict identified. A single-headquarters rule and review-time completeness are proposed service policies, not DB CHECKs.

**Database impact:** No DBML change. Full historical company-decision records would require a separate proposal if demanded.

**Approval classification:** Approval authority needs team approval; headquarters validation is a minor implementation policy. See checklist 3.

## BR06 — Employer access depends on approved company affiliation

Original unresolved question: Define who approves/revokes memberships and whether membership history is needed.

**Existing requirement:** FRD lets Company Representatives manage approved Recruiter access according to company policy.

**Current design / assumption:** One membership row per company/user; reviewer is a user FK; role and ACTIVE access are service checks.

**Recommendation — pending approval:** Administrator bootstraps/approves Company Representative access. An ACTIVE Representative may approve or revoke Recruiter access only for their own APPROVED company; Administrator may also manage it. Reject self-approval. Reuse the existing membership for renewal and retain it for referenced evidence.

**Conflict / scope check:** No conflict identified. The exact approver chain and self-approval restriction are proposed policies.

**Database impact:** No schema change. Separate membership episodes/history would require a scoped proposal.

**Approval classification:** Team approval of access authority; retained-record scope also covered by checklist 5. See checklist 3.

## BR11 — Media files have ordered metadata

Original unresolved question: Resolve Sprint I up-to-60 wording versus FRD 30–60 and configure authoritative limits.

**Existing requirement:** FRD Create Portfolio Post describes a 30–60-second video and permits images/other media.

**Current design / assumption:** Positive optional duration CHECK; media_type includes five categories. No 30–60 range CHECK.

**Recommendation — pending approval:** Use the FRD 30–60-second range for VIDEO publication validation, leaving images/other supported media valid. Clarify the Sprint I label to 30–60 in a future UI wording change; do not modify the preserved mockup. Validate actual file/type/duration when publishing; choose file-size limits during implementation.

**Conflict / scope check:** Actual source wording discrepancy: Sprint I says up to 60, which would admit shorter videos. Keep FRD authoritative unless the team approves an FRD revision.

**Database impact:** No DBML change; application validation/configuration data only.

**Approval classification:** Team should acknowledge the authoritative wording; relaxing the minimum requires an explicit requirement decision. See checklist 4.

## BR15 — A current verification matches the post and tagged company

Original unresolved question: Confirm whether rejected requests can be resubmitted in place and whether decision history is required.

**Existing requirement:** FRD supports tagging a company and approving/rejecting its verification request; it does not demand an event-history table.

**Current design / assumption:** Unique verification post_id; composite post/company FK; one current request record.

**Recommendation — pending approval:** Allow rejected requests to be corrected/resubmitted in the same record: set PENDING and clear review/rejection/showcase metadata atomically. Keep author and tagged company fixed after a verification record exists. Retagging an existing referenced verification is not a simple independent field edit; defer it or prepare a tested migration workflow. Do not add verification decision history.

**Conflict / scope check:** No conflict identified with stated requirements. Retry/reset behavior and limits are proposed policies.

**Database impact:** No schema change for same-company retry. Immediate matching FKs constrain retagging; a multi-company/history requirement needs a separate proposal.

**Approval classification:** Team approval of one-record retry and no decision history. See checklist 5.

## BR17 — Approved work receives a derived verified indicator

Original unresolved question: Define which edits require re-verification and how earlier application evidence is retained.

**Existing requirement:** FRD permits a verified indicator only after an authorized company approval.

**Current design / assumption:** Approval stored in the current verification, post content stored once, applications reference the live post. Audit notes already call for claim-changing edits to be reverified.

**Recommendation — pending approval:** Reset approval to PENDING and remove showcase selection when title, description, media or collaboration claim materially changes. Profile/feed/portfolio display changes alone need not reset a claim. Keep author/company fixed for an existing request. Retain live portfolio references in applications and disclose that edited content/badges may change; defer immutable snapshots.

**Conflict / scope check:** No immutable application snapshot requirement is stated. Reusing approval for materially different work would undermine the FRD verification meaning; the exact edit trigger is proposed policy.

**Database impact:** No schema change for reset and live references. Immutable submitted evidence would need a separate design/implementation proposal; do not promise it now.

**Approval classification:** Team must approve the edit boundary and live-evidence tradeoff. See checklist 7.

## BR18 — Only approved content can be showcased

Original unresolved question: Confirm automatic company display versus representative selection; distinguish verified-work listing from selected showcase.

**Existing requirement:** FRD overview emphasizes approved work on both presences; detailed showcase requirement permits representative selection.

**Current design / assumption:** APPROVED and SHOWCASED are separate; SHOWCASED requires APPROVED.

**Recommendation — pending approval:** Treat approved company-linked work as available in a verified-work listing; use SHOWCASED only for selected featured content. Query the same post for both, with visibility/access checks; do not auto-write SHOWCASED on approval.

**Conflict / scope check:** Source ambiguity, not a declared schema contradiction: automatic approved-work presence versus curated public showcase. The team must settle the intended display interpretation.

**Database impact:** No DBML change; presentation/query policy only.

**Approval classification:** Team approval of company display semantics. See checklist 6.

## BR20 — Engagement views identify exactly one target

Original unresolved question: Decide whether anonymous views, repeat-view counting and retention are required.

**Existing requirement:** FRD requires company engagement and platform analytics without specifying anonymous traffic or precise metric definitions.

**Current design / assumption:** view_events requires viewer_user_id and exactly one target. Repeated events are not unique.

**Recommendation — pending approval:** Track signed-in views only. Preserve distinct events and label total-view counts separately from distinct-viewer counts; derive both by query. Do not invent anonymous tracking or automated purge in Sprint II.

**Conflict / scope check:** No missing anonymous-view requirement found. Counting/retention definitions are proposed policies.

**Database impact:** No schema change. Anonymous events would conflict with mandatory viewer identity and require a proposal.

**Approval classification:** Implementation follow-up; team only needs to decide if anonymous tracking is added later.

## BR22 — Applications use existing student and job identities

Original unresolved question: Define withdrawal, repeat applications and deadline/time-zone policy.

**Existing requirement:** FRD requires submitting applications and tracking them; it does not expressly promise withdrawal or repeat submissions.

**Current design / assumption:** UNIQUE(job_id,student_user_id) applies to every stored lifecycle state; application status is configurable.

**Recommendation — pending approval:** Keep one submission per student/job and do not create a second row after rejection or expiry. Defer withdrawal/resubmission features; a Withdrawn label could later be lookup data, but does not release uniqueness. Submit only to ACTIVE jobs before a supplied deadline; null deadline means no time cutoff while the job is open. Use a documented UTC comparison and display the local time.

**Conflict / scope check:** No repeat/withdrawal requirement found. These limits and cutoff semantics are proposed policies supported by the audited model.

**Database impact:** No schema change; lookup/configuration and service validation only. Multiple application episodes require a schema proposal.

**Approval classification:** Team approval of submission lifecycle and deadline behavior. See checklist 5.

## BR25 — Additional application materials are distinct from portfolio links

Original unresolved question: Define any employer-required extra materials before designing dynamic forms.

**Existing requirement:** FRD permits other required application information but does not specify employer-defined question/form structures.

**Current design / assumption:** Applications have optional cover_note, repeating application_materials, and portfolio credential links.

**Recommendation — pending approval:** Support optional cover notes and file attachments using existing fields; configure/validate any agreed static required material types in the service. Do not introduce dynamic employer questionnaires. Do not claim a per-job configurable required-material form is implemented.

**Conflict / scope check:** No explicit questionnaire/schema requirement found. If the team promises per-job arbitrary required fields, the current model has no definitions for them.

**Database impact:** No schema change for the stated scope. Dynamic job-specific forms would require a separate proposal.

**Approval classification:** No current approval needed to defer unrequested forms; team decision only if that scope is added.

## BR26 — Current application status and history remain consistent

Original unresolved question: Select statuses, legal transitions and timestamp ordering conventions.

**Existing requirement:** FRD lists Submitted, Under Review, Interview, Rejected and Selected/Offered or equivalent application statuses.

**Current design / assumption:** Status lookup plus current status/history; no seed vocabulary or legal-transition CHECK.

**Recommendation — pending approval:** Propose lookup labels Submitted, Under Review, Interview, Rejected, Selected/Offered. Allow Submitted to Under Review or Rejected; Under Review to Interview, Rejected or Selected/Offered; Interview to Rejected or Selected/Offered. Keep terminal states terminal for ordinary recruiters; an Administrator correction must record a new history event. Write current state/time and history in one transaction with UTC times; retain history_id to identify simultaneous events.

**Conflict / scope check:** No conflict identified. FRD mandates status support, not these exact transition edges or terminal-state restrictions.

**Database impact:** No DBML change. If approved, status labels are configuration rows and transitions are service logic.

**Approval classification:** Team approval of status labels and transitions. See checklist 8.

## BR28 — Invitations identify a specific student and opportunity

Original unresolved question: Define invitation expiration, reinvitation and declined invitation application behavior.

**Existing requirement:** FRD requires inviting specific students and supporting direct applications.

**Current design / assumption:** One invitation per student/job; optional unique matching invitation/application tuple.

**Recommendation — pending approval:** Use SENT/VIEWED before application, APPLIED after matched submission, and DECLINED/EXPIRED where appropriate. Renew an expired/declined invitation in the existing row while no application exists; do not create episodes/history. A student may apply directly even after declining an invitation if the job is still eligible, leaving invitation_id null; match a usable invitation when it is supplied.

**Conflict / scope check:** No conflict identified. Renewal and direct-application behavior after decline are proposed policies.

**Database impact:** No schema change. Extra invitation episodes need a proposal. APPLIED synchronization is transactional.

**Approval classification:** Team approval of the one-record recruiting lifecycle. See checklist 5.

## BR30 — Messaging connects permitted participants

Original unresolved question: Decide whether group chat is supported and whether participant removal must retain message references.

**Existing requirement:** FRD describes direct/permitted messaging, not group chat.

**Current design / assumption:** Conversation participants support multiple users; sender must be a participant; logical minimum does not express exactly two.

**Recommendation — pending approval:** Offer one-to-one messaging only, with exactly two distinct permitted participants at creation. Retain participant rows referenced by messages; revoke sending/reading through authorization instead of deleting referenced membership. Limit interactions to the FRD-supported recruiting, advising and company/staff contexts.

**Conflict / scope check:** No group-chat requirement found. Exactly-two and permission routing are proposed service policies, not FK guarantees.

**Database impact:** No schema change; the current tables could hold groups but the proposed UI scope does not expose them.

**Approval classification:** Team approval of messaging scope. See checklist 9.

## BR32 — Notifications have a recipient and typed navigation context

Original unresolved question: Define delivery fan-out, preference and reliable delivery/retry policy.

**Existing requirement:** FRD requires relevant notifications without fixing fan-out, preference models or delivery technology.

**Current design / assumption:** One recipient per notice, zero/one typed target, target FKs and read consistency CHECK.

**Recommendation — pending approval:** Create one notice per authorized intended recipient; use existing typed targets and zero target for system announcements. Validate notification type/target pairing. Coordinate database notice creation with the originating transaction; retries must avoid duplicate business writes. Defer new preference tables, external channels and exactly-once delivery promises.

**Conflict / scope check:** No conflict identified. FRD does not demand email/push preference tables or exactly-once delivery.

**Database impact:** No schema change for in-app notices; delivery reliability is implementation work.

**Approval classification:** Engineering follow-up; no separate Sprint II approval unless new channels/preferences are added.

## BR33 — Advisor access requires authorization or assignment

Original unresolved question: Define access revocation, assignment renewal and history policy.

**Existing requirement:** FRD limits Advisor access to authorized or assigned students.

**Current design / assumption:** One assignment per advisor/student; PENDING, ACTIVE, REVOKED lifecycle; feedback/recommendations retain references.

**Recommendation — pending approval:** Use existing ACTIVE assignment authorization; revoke access immediately in the service and keep referenced rows. On later renewal, reuse the pair’s record and current timestamps; no assignment-episode history. Retain feedback privately for the student and authorized staff, without granting a revoked advisor renewed access.

**Conflict / scope check:** No assignment-history requirement found. Renewal and historical-access details are proposed service policies.

**Database impact:** No schema change. Separate assignment episodes/history would require a proposal.

**Approval classification:** Team approval of retained one-record scope (checklist 5); authorization restriction itself is required. See checklist 5.

## BR35 — Advisors recommend opportunities to assigned students

Original unresolved question: Define repeated recommendations after dismissal or changed job content.

**Existing requirement:** FRD allows Advisor recommendations to assigned students without defining repeated recommendation events.

**Current design / assumption:** UNIQUE(assignment_id,job_id) gives one stored recommendation per pair.

**Recommendation — pending approval:** Update/reopen the same recommendation when appropriate instead of inserting duplicates; keep current message/status rather than add an event-history table. Recheck ACTIVE assignment and job eligibility before sending.

**Conflict / scope check:** No recommendation-history requirement found. Reopening behavior is proposed policy.

**Database impact:** No schema change. Separate recommendation episodes require a proposal.

**Approval classification:** Team approval of one-record renewal scope. See checklist 5.

## BR36 — Assistance and analytics are derived from source records

Original unresolved question: Define completeness thresholds and engagement aggregation rules.

**Existing requirement:** FRD asks for completeness/activity assistance and analytics without numerical thresholds.

**Current design / assumption:** Completeness, activity and counts are derived; no cached metric entities are required.

**Recommendation — pending approval:** Use clearly named computed indicators such as missing optional profile information, no visible portfolio media, or no submitted applications. Do not call required major/year missing on a valid student_profiles row. Let authorized configuration/UI choose useful thresholds later; label raw totals versus distinct users explicitly.

**Conflict / scope check:** No threshold value is an existing requirement. A valid profile cannot lack its NOT NULL major/year merely because a dashboard wants such a filter.

**Database impact:** No schema change; queries and validated settings only.

**Approval classification:** Minor analytical wording/implementation follow-up, not a Sprint II team blocker.

## BR37 — Reports target exactly one existing object

Original unresolved question: Choose retention, resolution transitions and response workflow.

**Existing requirement:** FRD requires reports, administrative review and company/staff response.

**Current design / assumption:** Exactly one typed report target, state OPEN/UNDER_REVIEW/RESOLVED/DISMISSED, repeating moderation actions; no dedicated company reply table.

**Recommendation — pending approval:** Move reports through existing states with authorized Administrator decisions and attributable actions. Restrict report visibility to authorized parties; permit company response through existing company/staff messaging. Keep target references and use RESTRICT deletion for report targets as DBML comments specify; defer exact purge durations.

**Conflict / scope check:** No required company-response table/history was identified; permitted messaging supports the stated communication. Detailed confidentiality/retention workflow is proposed policy.

**Database impact:** No logical schema change; access/workflow and physical delete-policy implementation only.

**Approval classification:** Retention principle needs team approval (checklist 10); exact processing details can be finalized during implementation. See checklist 10.

## BR38 — Moderation actions preserve accountable decisions

Original unresolved question: Define legal sanctions, unmoderation and retention/purge policy.

**Existing requirement:** FRD requires moderation, account controls and removal of inappropriate/fraudulent employment content.

**Current design / assumption:** Existing action enums plus post/comment/message/job/user/company lifecycle fields.

**Recommendation — pending approval:** Use declared action/state values; apply target state and moderation action atomically. Restore only through authorized Administrator review and record the correction as a new action rather than erase earlier evidence. Do not invent automatic sanctions or purge durations.

**Conflict / scope check:** No specific sanction ladder or automated punishment requirement found. Those would be proposed policies.

**Database impact:** No schema change; use existing action rows and states.

**Approval classification:** Team approval of evidence-preserving retention; detailed sanction thresholds are later operational policy. See checklist 10.

## BR39 — Category merges preserve references and avoid cycles

Original unresolved question: Define cross-discipline major merges and merge/restore policy.

**Existing requirement:** FRD requires category creation, update, merge and deactivation.

**Current design / assumption:** Merge destination FKs and self/inactive CHECKs; per-discipline major-name uniqueness.

**Recommendation — pending approval:** Have Administrators merge into an existing active destination after cycle and duplicate-junction checks, reassign references transactionally, and keep the old category inactive. Preserve the destination major’s discipline and intentionally update filters when a cross-discipline merge is chosen. Do not offer automatic reversal of a completed merge; correct by explicit administrative edits.

**Conflict / scope check:** No conflict identified. Cycles, reassignment order and restoration semantics are service/transaction obligations beyond the CHECKs.

**Database impact:** No schema change; reconcile duplicate junctions and immediate FKs in a tested transaction. Merge history/automatic undo would need a separate proposal if required.

**Approval classification:** Engineering workflow follow-up; the FRD already authorizes Administrator category management.

## BR40 — System-wide configurable policies have attributable changes

Original unresolved question: Define allowed setting keys, value validation and which enum domains need future configuration support.

**Existing requirement:** FRD requires configurable media/account/reporting policies and application statuses.

**Current design / assumption:** system_settings stores text values; application_statuses is editable data; other state vocabularies are DBML enums.

**Recommendation — pending approval:** Validate a small allowlist of settings for existing configurable policies and use application_statuses for stage labels. Keep lifecycle enums fixed for this release; do not imply arbitrary new enum values can be entered through settings. No new configuration entities are needed for this scope.

**Conflict / scope check:** No conflict for stated policy configuration. If the team promises freely editable enum vocabularies, the current DBML does not support that promise.

**Database impact:** No schema change for existing settings/status rows. Extending enum domains is a separate controlled schema revision.

**Approval classification:** Implementation follow-up; approve extra configurability only if it is explicitly added to scope.

## BR41 — Referenced evidence is not silently erased

Original unresolved question: Decide immutable application evidence, claim edits after application, physical delete actions and retention.

**Existing requirement:** FRD does not specify immutable application evidence, detailed deletion behavior or retention duration.

**Current design / assumption:** Applications reference live posts/media; witnesses and audit FKs protect identities; inactive/removed states exist.

**Recommendation — pending approval:** Keep live evidence references, no snapshots/version tables, and disclose their mutability. Prefer inactive/removed states and reject physical deletion of referenced evidence/audit objects. Preserve stored file references during the presentation scope; agree retention periods before a production purge feature. Do not promise immutable submissions or permanent retention.

**Conflict / scope check:** No immutable-snapshot or fixed-duration requirement found. Unrestricted deletion could undermine required application review and audit records.

**Database impact:** No logical schema change for the recommendation. Immutable versions or a new purge/archive design require a separate proposal if chosen.

**Approval classification:** Team approval of the live-evidence and retention principles. See checklist 10.

## Separate implementation follow-ups

These remain recommendations, not silently approved policies. They do not block the three-case logical-design presentation and do not justify a new schema now.

- BR02: choose/test email normalization, physical collation and secure session parameters.
- BR05: headquarters selection validation and company review-time consistency.
- BR20/BR36: signed-in event counting, named totals/distinct metrics and assistance thresholds.
- BR25: agree static file validation only if extra materials are actually required; do not promise dynamic forms.
- BR32: recipient fan-out, type/target validation, transactional notification writes and retry behavior.
- BR37/BR38: confidentiality, existing-state processing and documented administrative corrections.
- BR39: tested merge transactions, duplicate reconciliation and cycle prevention.
- BR40: validate existing setting keys/values; configurable status rows do not make enums freely editable.
- Exact storage limits, delivery technology and purge periods can be finalized before implementation/production. They are not missing ERD tables or presentation blockers.