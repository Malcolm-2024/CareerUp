# CareerUp Team Decision Checklist

**All items are pending team approval. Recommendations have not been implemented.** Database impact below means what would be needed if approved, not a change already made.


1. **Keep one sign-in role per account?**

   Recommended answer: Yes. Use the existing required role_id; defer multi-role accounts.

   Database: No schema change; multiple simultaneous roles would need a separate proposal.

   Competition: No change; the three actors already have distinct roles.

2. **Keep the current required profile and post fields?**

   Recommended answer: Yes. Require major/graduation year before saving a Student profile and a title for a project post; school and post description stay optional. These are retained design choices, not all literal FRD mandates.

   Database: No schema change; permitting null major, graduation year or post title would need a separate proposal.

   Competition: No change; the example has its academic values and a project title.

3. **Who approves employer/advisor accounts and company access?**

   Recommended answer: Administrator approves employer/advisor accounts, companies and Representative access. An active same-company Representative or Administrator manages Recruiter memberships; no self-approval.

   Database: No schema change; authorization and review/state writes only.

   Competition: The existing approved actors stay valid; the approval-chain explanation would be clarified after approval.

4. **Keep the FRD’s 30–60-second video range?**

   Recommended answer: Yes. Validate it when publishing; reconcile the up-to-60 mockup wording later.

   Database: No schema change; service validation/settings only.

   Competition: No change; the 45-second example passes either wording.

5. **Keep one stored record per existing unique pair, without adding episode/history tables?**

   Recommended answer: Yes. One application per student/job; reuse current requests, invitations, memberships, assignments and recommendations for permitted retries/renewals. Defer repeat application submissions and new histories.

   Database: No schema change; many separate episodes would need a proposal.

   Competition: No change; duplicate application rejection remains correct.

6. **How should approved work appear on the company page?**

   Recommended answer: List eligible approved work as verified work; reserve SHOWCASED for selected featured content. Approval does not auto-select a showcase.

   Database: No schema change; same-post queries/display policy only.

   Competition: No walkthrough change; this resolves company-display interpretation.

7. **How do edits affect verified work and submitted application evidence?**

   Recommended answer: Claim-changing edits reset verification/showcase; existing request author/company remain fixed. Applications keep live references, with no immutable snapshots promised.

   Database: No schema change for the recommendation; immutable/versioned evidence needs a separate proposal.

   Competition: No change to the unedited example. Any future edit/retry demonstration needs explicit approval.

8. **Use a simple application lifecycle with a clear deadline cutoff?**

   Recommended answer: Use Submitted, Under Review, Interview, Rejected and Selected/Offered; update history atomically. Accept ACTIVE-job submissions before a supplied deadline using UTC; defer withdrawal/resubmission features.

   Database: No schema change; if approved, lookup/configuration data and service transitions only.

   Competition: No change; Submitted is already used and the sample deadline is later.

9. **Offer one-to-one messaging only in the current scope?**

   Recommended answer: Yes. Require two distinct permitted participants and retain participant rows referenced by messages. Defer group-chat UI.

   Database: No schema change; service authorization/count validation only.

   Competition: No change; messaging scope is outside the three demonstrations.

10. **Keep referenced evidence and audit records instead of deleting them?**

   Recommended answer: Yes. Use existing lifecycle states and restrictive deletion; defer exact purge periods to implementation. Do not promise permanent retention.

   Database: No logical schema change; delete-policy implementation and retention settings later.

   Competition: No change; this is a preservation principle for later lifecycle operations.

## Documentation improvements requiring no policy approval

112 field descriptions were clarified without changing their meaning or any metadata. Requirement/assumption/proposal labels and links to this review were added. The consistency report records the verification and historical embedded wording. These wording improvements do not authorize any recommendation above.