# CareerUp database design review — 14 October 2026

## Judgment
The 48-table design is defensible for CareerUp's complete five-role system, but 48 is not a minimum established by the Functional Requirements. It is too much to explain as one screen. The primary readability failure was the diagram layout and simultaneous display of cross-system references, rather than proof that the underlying entities were all unnecessary.

The FRD includes accounts/permissions, academic profiles and skills, companies/locations/membership, visual projects, verification, social actions, jobs/applications, invitations/shortlists, messaging, notifications, advising, moderation and administration. Supporting this full scope is materially larger than the three competition use cases. A smaller diagram containing only the competition entities would omit required system functionality.

## Are any tables unnecessary?
No table was found to be an accidental duplicate that can safely be deleted without changing a current behavior or guarantee. Two history tables go beyond explicit FRD wording: post_shares records individual share events; account_reviews records attributable approval/rejection history. Both are reasonable, but optional product choices. Removing both gives 46 tables only if the team explicitly accepts losing those histories and revises BR19 and BR04. No deletion has been applied.

Named candidate lists, application status history and verification resubmission/history policies also reflect design choices rather than every table being mandated verbatim. A single saved-candidate list could replace headers/items only if multiple named lists are deliberately abandoned. Current-status-only application tracking could omit history only if the team accepts that loss. These are scope decisions, not automatic normalization fixes.

Permissions and role_permissions stay: the administrator's Manage Roles and Permissions is explicitly required. Separate student, post and job skill junctions model different relationships. Verification is separate from authored posts because it stores a company's optional decision. Invitations differ from applications; private notes differ from status changes; advising feedback differs from opportunity recommendations. Typed social tables preserve foreign keys and distinct data meanings. Locations are repeating company data. Conversation participants support membership and message-sender integrity.

## Normalization and cardinality
Repeating skills, media, locations, application attachments and candidate-list members are separate records rather than comma-separated fields. Reference taxonomies are shared. Composite keys prevent duplicate associations. Composite foreign keys intentionally repeat ownership or company identifiers to prevent mismatched evidence and cross-company links. This is controlled redundancy; the package does not claim strict third normal form for every relation.

All 109 FK tuples point to compatible, declared unique parent tuples. PK, FK, required/optional metadata and child uniqueness agree with the dictionary and relationship register. A NOT NULL FK does not force a parent to have children. For example, a post can have zero media rows under FK rules; requiring complete media before publication remains workflow validation. The user/student-profile relation is 1 to 0..1 at the user end, because not every user is a student. Application evidence is many-to-many through application_portfolio_posts; ownership is protected by its composite links.

## Genuine compatibility correction in the new copy
Four category merge CHECKs referred to their own AUTO_INCREMENT primary key: academic_disciplines, majors, industries and skills. MySQL forbids AUTO_INCREMENT columns in CHECK expressions. The new reviewed DBML retains the source-inactive CHECK and existing destination FK; self-target and cycle rejection are explicitly assigned to Sprint III transactional validation. This changes the declared enforcement location, not tables, fields, indexes, relationships or cardinalities. Original files remain intact. This correction predates and is independent of the five advanced proposals.

MySQL reference: https://dev.mysql.com/doc/refman/8.0/en/create-table-check-constraints.html
FK reference: https://dev.mysql.com/doc/refman/8.0/en/create-table-foreign-keys.html

Target MySQL 8.0.16 or newer for enforced CHECK constraints. A physical MySQL migration must also resolve enum representation, index names, constraint names, referential actions and creation ordering. No database was deployed or SQL migration executed: Sprint II is a logical design deliverable. Geometry and metadata verification do not prove a generated migration executes successfully.

## What changed in the actual ERDs
The master keeps all 48 tables, 299 fields and 109 foreign keys. Compact boxes now reflect actual attributes instead of each table's relationship degree. Tables are grouped in nine functional regions, with distinct ports and orthogonal routes. Lines do not cross table interiors; unavoidable connector crossings use white separation and do not represent joins. The master remains dense and is a complete technical reference, not the default presentation sheet.

Sixteen readable system sections distribute all tables and foreign keys: every table is fully documented as a core table exactly once; every FK appears on its child's section exactly once. Parent context cards show only keys and are labeled as partial. Three focused competition diagrams retain the original case table/relationship sets; they show key/business-field excerpts, not a replacement schema. The dictionary contains every field. R### labels link all views to the same exact-column cardinality register.

## Requirements and presentation consistency
All five roles and current three connected cases remain: create a portfolio post, obtain company verification, apply using selected portfolio evidence. The application links to a live post, not an immutable snapshot. One verification record per post is the current unique-key design, not a multi-attempt audit history. Verification alone does not grant reviewer authority; approved company membership and role checks are application authorization. Verified-only application evidence is not a general database requirement. The old interactive backup is preserved unchanged, including its prior taxonomy CHECK explanation; use the new dictionary and reviewed DBML as the canonical compatibility reference.

## Remaining team obligations
Decide single versus multiple account roles; required attachment/publication policies; permitted verification resubmission and edit/revocation behavior; post edits/deletion after application; retention policies; named-list/history choices. Existing recommendations remain unapproved. See the copied team decision checklist for the full wording. None blocks explaining the current logical schema, but policies must be settled before Sprint III implementation.

Verify GitHub contributions, meeting records, two face-to-face meetings, meeting photos and Scrum Master responsibilities against the professor's rubric. This package does not fabricate or certify those records. Rehearse the three case sheets before using the complete master. Browser interaction and a physical MySQL build are not newly verified by this revision.

## Table-by-table scope assessment

### roles
- Purpose and justification: Shared role identity for all five roles; not a separate user table per role.
- Requirements: All Roles: Account Registration; Administrator: Manage Roles and Permissions
- Recommendation: Keep

### permissions
- Purpose and justification: Configurable capabilities are explicitly required; hard-coding them would narrow the FRD.
- Requirements: Administrator: Manage Roles and Permissions
- Recommendation: Keep

### role_permissions
- Purpose and justification: Resolves many roles to many capabilities without a comma-separated permission column.
- Requirements: Administrator: Manage Roles and Permissions
- Recommendation: Keep

### users
- Purpose and justification: Shared account, credentials, contact information and effective account state.
- Requirements: All Roles: Account Registration, Sign-in/Sign-out, Profile Management
- Recommendation: Keep

### student_profiles
- Purpose and justification: Academic details belong to the Student subtype; other roles need not have them.
- Requirements: Student: Manage Student Profile and Portfolio
- Recommendation: Keep

### schools
- Purpose and justification: Shared school identity avoids spelling duplicates and supports school filtering.
- Requirements: All Roles: Profile Management; Recruiter: Search and Discover Students
- Recommendation: Keep

### academic_disciplines
- Purpose and justification: Broad disciplines and specific majors are distinct explicitly supported filters.
- Requirements: Student: Create Portfolio Post; Administrator: Manage Skills and Academic Categories; Additional 2/4
- Recommendation: Keep

### majors
- Purpose and justification: Specific majors belong to disciplines; supports consistent student/post classification.
- Requirements: Student: Manage Student Profile and Portfolio; Recruiter: Search and Discover Students; Administrator: Manage Skills and Academic Categories
- Recommendation: Keep

### industries
- Purpose and justification: Controlled company industry classifications, including admin merge/deactivation.
- Requirements: Company Representative: Manage Company Profile; Administrator: Manage Skills and Academic Categories
- Recommendation: Keep

### skills
- Purpose and justification: Shared standardized skill vocabulary.
- Requirements: Student: Manage Skill Tags; Administrator: Manage Skills and Academic Categories; Additional 5
- Recommendation: Keep

### student_skills
- Purpose and justification: Profile skills and project-specific evidence are different associations; do not merge with post_skills.
- Requirements: Student: Manage Student Profile and Portfolio; Manage Skill Tags; Recruiter: Search and Discover Students
- Recommendation: Keep

### companies
- Purpose and justification: Official company identity reused by jobs, membership and collaboration.
- Requirements: Company Representative: Manage Company Profile; Administrator: Manage Company Accounts
- Recommendation: Keep

### company_locations
- Purpose and justification: FRD specifies locations; a company may have several. One flattened address would lose repeating data.
- Requirements: Company Representative: Manage Company Profile; Recruiter: Post Job or Internship
- Recommendation: Keep

### company_memberships
- Purpose and justification: Separates role identity from authorized company affiliation.
- Requirements: Company Representative: Manage Company Recruiting Team; Recruiter: Manage Recruiting Activity; Additional 6
- Recommendation: Keep

### posts
- Purpose and justification: One shared content entity for portfolio/company posts; feed and portfolio need no duplicate tables.
- Requirements: Student: Create Portfolio Post; Company Representative: Publish Company Content
- Recommendation: Keep

### post_media
- Purpose and justification: Repeating media child records preserve order and metadata without repeated project descriptions.
- Requirements: Student: Create Portfolio Post; Company Representative: Publish Company Content; Additional 1
- Recommendation: Keep

### post_skills
- Purpose and justification: Many-to-many project tags; paired PK prevents duplicate tags.
- Requirements: Student: Manage Skill Tags; Additional 5
- Recommendation: Keep

### collaboration_verifications
- Purpose and justification: Optional approval has a different actor and lifecycle from a post; merging it into posts obscures that boundary.
- Requirements: Student: Participate in Verified Collaboration; Company Representative: Verify Student Collaboration, Manage Collaborative Showcases; Additional 6/7
- Recommendation: Keep

### user_follows
- Purpose and justification: Stores the followed-user interpretation used by the current design. Exact following semantics remain a product interpretation, not guaranteed by the words alone.
- Requirements: Student: Manage Professional Network and Content Discovery; Overview: follow interesting content
- Recommendation: Keep

### post_likes
- Purpose and justification: Who likes which post; duplicate pair and unlike semantics differ from comments or share events.
- Requirements: Student: Browse and Interact With Discovery Feed; Additional 3
- Recommendation: Keep

### post_comments
- Purpose and justification: Repeated authored text with moderation state; not the same entity as a like/save.
- Requirements: Student: Browse and Interact With Discovery Feed; Additional 3; Administrator: Moderate Posts and Social Content
- Recommendation: Keep

### post_saves
- Purpose and justification: Persistent saved content is needed to retrieve bookmarks later.
- Requirements: Student: Browse and Interact With Discovery Feed; Manage Professional Network and Content Discovery; Additional 3
- Recommendation: Keep

### post_shares
- Purpose and justification: Sharing is required; a stored history of repeated share events, channels and timestamps is not explicit. Keep for share analytics, or approve untracked link sharing before removal.
- Requirements: Student: Browse and Interact With Discovery Feed; Additional 3
- Recommendation: Optional recording choice

### saved_companies
- Purpose and justification: Persistent saved employers are distinct from saved posts; a generic target ID would weaken FK integrity.
- Requirements: Student: Manage Professional Network and Content Discovery; Company Representative: View Company Engagement
- Recommendation: Keep

### view_events
- Purpose and justification: The FRD explicitly includes views. Some persistent view-count source is necessary; this table already covers post/company/job targets with real FKs. Raw event granularity/retention are choices.
- Requirements: Company Representative: View Company Engagement; Administrator: Generate Analytics and Reports
- Recommendation: Keep

### job_postings
- Purpose and justification: Persistent opportunity record, company and optional company-owned location.
- Requirements: Recruiter: Post Job or Internship; Student: Apply for Job or Internship
- Recommendation: Keep

### job_skills
- Purpose and justification: Multiple job skills, including required/preferred designation; different from a student or post skill.
- Requirements: Recruiter: Post Job or Internship; Search and Discover Students
- Recommendation: Keep

### job_disciplines
- Purpose and justification: Multiple permitted/preferred disciplines without repeating job details.
- Requirements: Recruiter: Post Job or Internship; Additional 4
- Recommendation: Keep

### application_statuses
- Purpose and justification: Configurable application status vocabulary is specifically required; do not fold it into an immutable enum just to remove a table.
- Requirements: Administrator: Manage System Configuration; Additional 11
- Recommendation: Keep

### applications
- Purpose and justification: Associates student/job and carries submission/status data.
- Requirements: Student: Apply for Job or Internship, Manage Applications; Recruiter: Review and Manage Applications
- Recommendation: Keep

### application_portfolio_posts
- Purpose and justification: Several owned posts per application and reuse across applications; composite ownership FKs are intentional integrity protection.
- Requirements: Student: Apply for Job or Internship; Additional 10
- Recommendation: Keep

### application_status_history
- Purpose and justification: History is a current design decision rather than an explicit mandatory event log; retain the existing progress/history rule. Replacing it with current status would deliberately lose that rule and capability.
- Requirements: Student: Manage Applications; Recruiter: Review and Manage Applications
- Recommendation: Keep

### job_invitations
- Purpose and justification: Discovery/invitation is independent of application; cannot merge the two without losing non-applicant invitations.
- Requirements: Recruiter: Invite Student to Apply; Additional 8/9
- Recommendation: Keep

### candidate_lists
- Purpose and justification: Named list container is a current design choice supporting candidate lists. Single saved-candidate support is an alternative, not a lossless merge.
- Requirements: Recruiter: Save or Shortlist Candidates
- Recommendation: Keep

### candidate_list_items
- Purpose and justification: Many students per list and student reuse across lists; preserves unique membership pairs.
- Requirements: Recruiter: Save or Shortlist Candidates
- Recommendation: Keep

### conversations
- Purpose and justification: Thread context may be general, job-only or application-linked.
- Requirements: All Roles: Messaging; Student: Communicate With Recruiters; Career Advisor: Communicate With Students
- Recommendation: Keep

### conversation_participants
- Purpose and justification: Participant membership and read state; supports sender-membership FK. A two-user-only replacement is a new group-chat policy.
- Requirements: All Roles: Messaging
- Recommendation: Keep

### messages
- Purpose and justification: Repeated authored messages, distinct from thread and membership records.
- Requirements: All Roles: Messaging
- Recommendation: Keep

### notifications
- Purpose and justification: Persistent recipient/read state and typed navigation targets. Its 20 fields and many FKs contribute heavily to the drawing, but removing typed FKs would reduce referential integrity.
- Requirements: All Roles: Notifications
- Recommendation: Keep

### advisor_student_assignments
- Purpose and justification: FRD requires authorized/assigned students, not unrestricted advisor access.
- Requirements: Career Advisor: Review Student Career Profile; Monitor Student Career Activity
- Recommendation: Keep

### portfolio_feedback
- Purpose and justification: Private assigned-student feedback; optional post handles whole-portfolio advice and work not yet posted.
- Requirements: Career Advisor: Provide Portfolio Feedback; Recommend Portfolio Content
- Recommendation: Keep

### opportunity_recommendations
- Purpose and justification: Advisor-origin recommendations to assigned students have a different purpose/actor from recruiter invitations.
- Requirements: Career Advisor: Recommend Opportunities
- Recommendation: Keep

### reports
- Purpose and justification: User complaint/case and exactly one reported target; distinct from the administrator response.
- Requirements: Administrator: Manage Reported Activity; Moderate Posts and Social Content; Manage Employment Content
- Recommendation: Keep

### moderation_actions
- Purpose and justification: FRD explicitly requires documenting actions. Multiple sanctions/decisions belong to a report; do not flatten the action log into one report text field.
- Requirements: Administrator: Manage Reported Activity; description: document administrative actions
- Recommendation: Keep

### system_settings
- Purpose and justification: Persistent named platform settings; value validation remains application logic.
- Requirements: Administrator: Manage System Configuration
- Recommendation: Keep

### application_materials
- Purpose and justification: Recruiter requirement names other application materials. Exact file types are policy, but removing file records without a supported substitute risks narrowing that requirement.
- Requirements: Student: Apply for Job or Internship; Recruiter: Review and Manage Applications
- Recommendation: Keep

### application_notes
- Purpose and justification: FRD explicitly permits notes/decisions. A private note should not manufacture a status-change event.
- Requirements: Recruiter: Review and Manage Applications
- Recommendation: Keep

### account_reviews
- Purpose and justification: Approval/authorization are supported requirements, but a repeating attributable decision history is not explicitly required. Current BR04 and the audit retain it, so removal changes that existing design guarantee.
- Requirements: All Roles: Account Registration; Administrator: Manage User Accounts
- Recommendation: Optional approval-history choice
