# CareerUp professor-coverage speaking notes

This is a logical design demonstration. Declared database constraints and Sprint III implementation plans are distinguished. Do not claim a deployed database or verified team evidence.

## Regular presentation guide

### 1. Overall database design

**Say:** CareerUp’s logical design has 48 tables organized into nine functional areas. Shared accounts connect the complete system: Student, Recruiter, Company Representative, Career Advisor and Administrator. This sprint designs the data; implementation follows in Sprint III.

**Point at:** Show the master and its functional-area groups.

**Why:** The design supports the complete application, not only the three competition screens.

### 2. Complete ERD

**Say:** This is the complete 48-table ERD. Each table shows attributes and primary and foreign keys, and the connectors show cardinality. We can zoom into a table or switch to an area view to make its details readable.

**Point at:** Show the full master, then zoom or open a functional-area view.

**Why:** Another developer must be able to understand the complete design.

### 3. Major entities and their purposes

**Say:** users identifies people; student_profiles stores academic details; companies and job_postings describe employers and opportunities. posts stores project evidence, applications connects students to jobs, and verification records company decisions. Advising, messaging and administration also have their own tables.

**Point at:** Find users, posts, applications; show the career-advising and administration area views.

**Why:** All five roles remain supported even though the competition focuses on student project evidence.

### 4. Relationships and cardinalities

**Say:** One student can have several posts, but each post has one author. Skills and posts can each have many connections, so post_skills stores their links. The walkthroughs also explain optional verification and application attachments; required child counts need completion logic beyond a foreign key.

**Point at:** Use the relationship inspector and the two endpoint counts.

**Why:** The counts reflect real activities and the actual audited keys and nullability.

### 5. Three Functional Requirements use cases

**Say:** Our three cases demonstrate different functionality: creating project evidence, obtaining company confirmation, and submitting evidence for recruitment. They use the same student and post to show how records are reused. Each case connects to a named Functional Requirement.

**Point at:** Show Create Portfolio Post, Verify Collaboration and Apply for Job.

**Why:** The competition judges requirements-to-data support, not complexity alone.

### 6. Data Dictionary and important fields

**Say:** The dictionary documents all 48 tables and 299 fields. For each field it gives the name, description, type, key designation, and whether it is required or optional. We will show a project ID, an author reference and an optional description as examples.

**Point at:** Open posts in the dictionary and read the generated examples below.

**Why:** The dictionary turns the diagram into precise field definitions for Sprint III.

### 7. At least three important business rules

**Say:** Three examples are no duplicate skill tag on a post, verification must name the tagged company, and applications must attach the applicant’s own work. We explain why each rule matters and its declared PK, UNIQUE or FK support. Reviewer authorization and complete submission still need application validation in Sprint III.

**Point at:** Create Step 4, Verify Step 2, Apply Step 4; then the Business Rules page.

**Why:** Constraint declarations and planned application checks must not be confused with implemented behavior.

### 8. Sprint I UI review and resulting changes

**Say:** The supplied Sprint I create-post, verification and applications mockups helped us check the stored data against the screens. The audit separates portfolio and feed visibility, approval from showcase selection, and private application notes from status history. These are documented audit refinements; we cannot prove that every change was caused solely by a screen review.

**Point at:** Show the supplied screens, then the review-evidence page.

**Why:** UI review checks the design, but the Functional Requirements remain the source of truth.

### 9. Unresolved questions before Sprint III

**Say:** We still need team decisions on video duration wording, approved company listings versus selected showcases, repeat applications and verification retries, and editing submitted evidence. Existing stricter required fields and role policies also need confirmation. The recommendations are not team-approved decisions.

**Point at:** Open the Team Decision Checklist in the Consistency Report.

**Why:** Unresolved policies must be settled before implementation, not silently invented.

### 10. GitHub evidence

**Say:** The Sprint I materials identify our team repository. For Sprint II, we must show the actual ERD, dictionary, rules and supporting documents in GitHub, together with each member’s meaningful pushed contribution. Those Sprint II uploads and contributions have not been verified in this package; show the real repository after confirming them.

**Point at:** Open the real team repository in the audience browser and show the files and commit history.

**Why:** Local artifacts and these reminder checkboxes do not prove GitHub submission or team participation.

## Create Portfolio Post

**Requirement source:** Student: Create Portfolio Post; Manage Skill Tags. Additional Requirements 1 and 5.

### Step 1 — Identify the student

**Say:** Student 1001 already has an account and academic profile. These tables identify who is creating the portfolio post.

**Relationship and why:** Each student profile belongs to one account. Across all five roles, an account can have zero or one student profile, because only students need academic details. Student registration must ensure the profile exists.

**Rule and why:** This rule means the author must be an active Student. We need it because employer or disabled accounts should not publish student credentials. Our design supports it by an author reference in posts, plus Student-role and account-status checks during Sprint III.

**Enforcement:** Sprint III authorization; the FK checks that the author exists, not their role or active status.

**Point at:** Point to users, then student_profiles and roles. These identify the author and the kind of account.

**Stored fields:** `users.user_id`, `users.role_id`, `student_profiles.user_id`

**Functional Requirement:** This supports Create Portfolio Post and Manage Skill Tags: the student can publish project evidence and make its demonstrated skills discoverable.

**Transition:** Now that we know who the author is, we can save the project details.

### Step 2 — Save the project post

**Say:** We save post 5001 with its author, title, description and optional company tag. The project details belong in posts, not in the account record.

**Relationship and why:** One author can have zero or many posts, but each post has exactly one author. That is one-to-many because students can show several projects. A post may have no company tag; a company can be tagged in many posts.

**Rule and why:** This rule means a company tag is not approval. We need it because a student should not be able to claim company verification merely by tagging it. Our design supports it by an optional company FK and a separate verification decision; Sprint III will display the indicator from approved status.

**Enforcement:** Declared FK for a valid supplied company; Sprint III indicator logic.

**Point at:** Point to posts and its link to users. Then point to the optional company link.

**Stored fields:** `posts.post_id`, `posts.author_user_id`, `posts.title`, `posts.description`, `posts.company_id`

**Transition:** Next, we add the project’s video or image.

### Step 3 — Add the video or image

**Say:** post_media stores the video or image reference, media type and display order. Keeping files separate lets one project include several files.

**Relationship and why:** One published media post needs one or more media records, but each media record belongs to one post. That is one-to-many because a project can have several files. Publication validation, not the foreign key alone, enforces the minimum.

**Rule and why:** This rule means a published media post must contain valid media. We need it because an empty or invalid project cannot demonstrate the student’s work. Our design supports it by post_media file references and publication checks for file validity, quantity and duration in Sprint III.

**Enforcement:** Sprint III publication validation. Video duration wording still needs the team’s source clarification.

**Point at:** Point to posts and post_media. Explain that one post can have several media records.

**Stored fields:** `post_media.media_id`, `post_media.post_id`, `post_media.media_type`, `post_media.media_url`, `post_media.display_order`

**Transition:** Next, we connect the skills demonstrated by the project.

### Step 4 — Add skill tags

**Say:** The selected skills already exist in skills. post_skills records which ones belong to post 5001, keeping skill names in one shared list.

**Relationship and why:** A post can have zero or many skill tags, and a skill can appear on zero or many posts. post_skills resolves that many-to-many connection; each link names exactly one post and one skill.

**Rule and why:** This rule means the same skill cannot be attached twice to a post. We need it because duplicate tags would add no information and distort filtering. Our design supports it by the combined primary key on post_id and skill_id.

**Enforcement:** Declared database composite PK, to implement in Sprint III; active-skill checks also need application validation.

**Point at:** Point to post_skills between posts and skills. This linking table represents the many-to-many relationship.

**Stored fields:** `post_skills.post_id`, `post_skills.skill_id`

**Transition:** We can now check and publish the completed post.

### Step 5 — Publish the post

**Say:** We publish the same completed post in the portfolio and, when enabled, the feed. Its visibility fields determine where it appears.

**Relationship and why:** The portfolio and feed display the same post and its existing media and skill links. Reusing those records keeps the project consistent instead of creating another copy.

**Rule and why:** This rule means visibility and publication must use the same completed post. We need it because separate copies in the feed and portfolio could disagree. Our design supports it by portfolio_visible and feed_visible on posts, with completion validation before publication.

**Enforcement:** Stored visibility fields; Sprint III publication and access validation.

**Point at:** Point back to posts, then the existing media and skill links. This step uses records already shown.

**Stored fields:** `posts.status`, `posts.portfolio_visible`, `posts.feed_visible`

**Transition:** Next, we use this same post for company verification.

## Verify Company Collaboration

**Requirement source:** Student: Participate in Verified Collaboration. Company Representative: Verify Student Collaboration. Additional Requirements 6 and 7.

### Step 1 — Select the tagged post

**Say:** We submit the same post 5001 for company verification. The existing author and company tag identify whose work and which company are involved.

**Relationship and why:** Each post has one author and may have zero or one tagged company. A company can be tagged in many posts because several students may describe work with the same employer.

**Rule and why:** This rule means only approved work can display the verified indicator. We need it because a company tag by itself is not evidence of company approval. Our design supports it by a separate verification status that Sprint III will check before displaying the indicator.

**Enforcement:** Sprint III display logic; no separate verified-post copy is created.

**Point at:** Point to posts, its student author and the company tag. A tag and an approval are different things.

**Stored fields:** `posts.post_id`, `posts.author_user_id`, `posts.company_id`

**Functional Requirement:** This supports Participate in Verified Collaboration and Verify Student Collaboration: the student requests confirmation and the company records an authorized decision.

**Transition:** Next, we store the company verification request.

### Step 2 — Request verification

**Say:** The request stores the company, collaboration type, pending status and request time. Notifications support telling the representative that a review is needed.

**Relationship and why:** A company can have many requests, but each request belongs to one company because it reviews its own collaborations. A post has zero or one verification record; each verification belongs to one post. Approval is optional, and this design keeps one request record per post; retry/history policy remains unresolved.

**Rule and why:** This rule means the request’s company must match the tagged company. We need it because a different company should not approve a claim made about this company. Our design supports it by the composite foreign key linking the request’s post/company pair to the post.

**Enforcement:** Declared database composite FK, to implement in Sprint III.

**Point at:** Point to collaboration_verifications, then its post and company links. Notifications are separate from the decision.

**Stored fields:** `collaboration_verifications.verification_id`, `collaboration_verifications.post_id`, `collaboration_verifications.company_id`, `collaboration_verifications.collaboration_type`, `collaboration_verifications.status`

**Transition:** Before approval, we need to check the reviewer’s access.

### Step 3 — Check the reviewer’s access

**Say:** We check the reviewer’s account, role and company membership before recording a decision. These records identify the person and their affiliation.

**Relationship and why:** One role can be used by many accounts, but each account has one role in our current design. Company membership separately links the reviewer to a company; it is checked by the application, not a direct verification-to-membership foreign key.

**Rule and why:** This rule means only an authorized, active representative of the matching company may review. We need it because another company’s user must not approve this company’s collaboration. Our design supports it by users, roles and company_memberships, with authorization checked at review time in Sprint III.

**Enforcement:** Sprint III authorization. A valid reviewer FK alone cannot grant permission.

**Point at:** Point to users, roles and company_memberships. These support the authorization check; verification does not have a direct membership foreign key.

**Stored fields:** `users.user_id`, `users.role_id`, `users.status`, `company_memberships.user_id`, `company_memberships.company_id`

**Transition:** With access checked, we can record the decision.

### Step 4 — Record the decision

**Say:** The authorized representative approves the existing request. It stores the decision, reviewer and review time instead of duplicating the project.

**Relationship and why:** One user can review many requests. A request has zero or one reviewer while pending; a recorded decision must identify its reviewer. This keeps pending requests possible while making completed decisions accountable.

**Rule and why:** This rule means a decided request needs a reviewer and review time. We need it because the team must be able to identify who made a decision and when. Our design supports it by a CHECK requiring both fields whenever status is no longer PENDING.

**Enforcement:** Declared database CHECK, to implement in Sprint III; reviewer authorization remains an application check.

**Point at:** Point to collaboration_verifications and the reviewer link to users. The project itself is not duplicated.

**Stored fields:** `collaboration_verifications.status`, `collaboration_verifications.reviewed_by_user_id`, `collaboration_verifications.reviewed_at`

**Transition:** Now we can show the result using the same post.

### Step 5 — Show the verified result

**Say:** The existing post can now display an indicator based on the approved decision. Notifications communicate the result; this example does not select a showcase.

**Relationship and why:** The post, decision and notifications remain separate records with existing links. The indicator reads the approval; selecting a featured company showcase is a separate action.

**Rule and why:** This rule means showcased work must be approved. We need it because unapproved work should not appear as company-endorsed content. Our design supports it by a CHECK requiring APPROVED when showcase_status is SHOWCASED, plus indicator logic.

**Enforcement:** Declared database CHECK and Sprint III display authorization; showcase selection is not automatic.

**Point at:** Point to the existing post and approved verification record. The visible result comes from the stored decision.

**Stored fields:** `collaboration_verifications.status`, `collaboration_verifications.showcase_status`, `notifications.recipient_user_id`

**Transition:** Next, the student uses this project as evidence in a job application.

## Apply for Job

**Requirement source:** Student: Apply for Job or Internship; Manage Applications. Additional Requirements 10 and 11.

### Step 1 — Choose the opportunity

**Say:** The student chooses job 9001 from the company’s existing opportunities. job_postings stores the opportunity details; companies stores the employer information.

**Relationship and why:** One company can have zero or many jobs, but each job belongs to one company. That is one-to-many because employers can advertise several opportunities without repeating company details.

**Rule and why:** This rule means the student must be eligible and the job available. We need it because applications should not be submitted to unavailable or expired opportunities. Our design supports it by the job reference and Sprint III checks of availability, deadline and student eligibility.

**Enforcement:** Sprint III application validation; a job FK alone does not check availability.

**Point at:** Point to job_postings and companies. This is the opportunity the application will reference.

**Stored fields:** `job_postings.job_id`, `job_postings.company_id`

**Functional Requirement:** This supports Apply for Job or Internship and Manage Applications: the student submits owned portfolio evidence and can track its application status.

**Transition:** Next, we choose the student’s portfolio evidence.

### Step 2 — Choose portfolio evidence

**Say:** The student selects post 5001, reusing its author and verified result. This example uses approved work, but the requirements also permit owned unverified posts.

**Relationship and why:** One student can author many posts, but each post has one author. The selected post may have no verification, so approval is optional evidence rather than a requirement for every attachment.

**Rule and why:** This rule means evidence must be the applicant’s own portfolio work. We need it because an applicant must not submit another student’s project. Our design supports it by ownership-matching attachment FKs at the linking step, plus a PORTFOLIO-type check in Sprint III.

**Enforcement:** Declared composite FKs at Step 4; Sprint III validates post type. Approval is not mandatory.

**Point at:** Point to posts and its author link, then collaboration_verifications. Verification is useful here, not a requirement for every attachment.

**Stored fields:** `posts.post_id`, `posts.author_user_id`, `collaboration_verifications.status`

**Transition:** With the evidence selected, we can save the application.

### Step 3 — Save the application

**Say:** Application 10001 records student 1001, job 9001 and a starting status. The application links existing records rather than copying the student’s profile or job details.

**Relationship and why:** A student can have many applications and a job can receive many applications. Each application identifies one student and one job, resolving that many-to-many connection while storing the submission’s status.

**Rule and why:** This rule means a student/job pair cannot be duplicated. We need it because repeated rows for the same submission would create conflicting statuses. Our design supports it by a UNIQUE constraint on student_user_id and job_id.

**Enforcement:** Declared database UNIQUE, to implement in Sprint III. Repeat-application policy remains unresolved.

**Point at:** Point to applications, then its student, job and status links. The optional invitation does not change this example.

**Stored fields:** `applications.application_id`, `applications.student_user_id`, `applications.job_id`, `applications.status_id`

**Transition:** Next, we link the chosen project to that application.

### Step 4 — Link the portfolio post

**Say:** application_portfolio_posts connects application 10001 to post 5001. It stores their IDs, the matching student ID and display order.

**Relationship and why:** A submitted application needs one or more portfolio links, and a post can be reused in zero or many applications. Each linking row belongs to one application and one post. This avoids copying the project for each application.

**Rule and why:** This rule means an attachment must match both the applicant and the post’s author. We need it because a valid application ID and post ID alone could still connect different students. Our design supports it by two composite FKs using the same student_user_id witness, plus the combined attachment key.

**Enforcement:** Declared database composite FKs and PK; display order is also unique within the application.

**Point at:** Point to application_portfolio_posts between applications and posts. Explain the ownership check before discussing the key fields.

**Stored fields:** `application_portfolio_posts.application_id`, `application_portfolio_posts.post_id`, `application_portfolio_posts.student_user_id`, `application_portfolio_posts.display_order`

**Transition:** Finally, we complete the submission and record its starting status.

### Step 5 — Submit and track progress

**Say:** We complete submission and record the initial status history. The application stores current progress, while history and notifications support tracking and communication.

**Relationship and why:** An application can accumulate many history entries, and each history entry belongs to one application. Current status supports quick progress views; history explains changes. Submission must create the initial history entry.

**Rule and why:** This rule means submission needs at least one portfolio post and consistent current status/history. We need it because the employer needs evidence and a reliable record of progress. Our design supports it by application_portfolio_posts and status history, saved together with completion checks in Sprint III.

**Enforcement:** Sprint III transactional logic. FKs validate supplied links, but cannot count required child rows or synchronize history.

**Point at:** Point to applications, its portfolio links and application_status_history. Then point to the status lookup and notifications.

**Stored fields:** `applications.status_id`, `applications.submitted_at`, `application_status_history.application_id`, `application_status_history.status_id`

**Transition:** That completes the three activities: one project was created, verified and reused in an application.

## Dictionary examples — actual definitions

| Field | Type | Key | Required/optional | Description |
|---|---|---|---|---|
| posts.post_id | bigint | PK | Required | Identifier of the project/accomplishment record reused by the portfolio, verification request and application credential. Verification and application links do not create another post. |
| posts.author_user_id | bigint | FK | Required | Existing account that authored this content. For a portfolio post the service requires a Student; application credential composite FKs use this author identity to enforce applicant ownership. |
| posts.description | text | Neither | Optional | Optional explanation of the project, the student’s contribution and the claimed work/collaboration. Company reviewers and recruiters read the same stored description. |
| post_media.media_url | varchar(500) | Neither | Required | Storage location of the project video, image or other media reviewed by the company and recruiter. The database stores a reference, not the binary file. |
| applications.submitted_at | timestamp | Neither | Required | Time this application was submitted, not the time the project or verification was created. |
