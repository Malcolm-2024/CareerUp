# Requirements coverage and verification limits

Source: the supplied official Sprint Cycle II Database Design instructions and competition announcement; Functional Requirements, audited DBML, dictionary, relationship register, audit and Sprint I materials remain authoritative.

| Official presentation requirement | Where to explain/show | Status |
|---|---|---|
| 1. Overall database design | Private regular guide item 1: Show the master and its functional-area groups. | Speaking cue provided; delivery/rehearsal not verified |
| 2. Complete ERD | Private regular guide item 2: Show the full master, then zoom or open a functional-area view. | Speaking cue provided; delivery/rehearsal not verified |
| 3. Major entities and their purposes | Private regular guide item 3: Find users, posts, applications; show the career-advising and administration area views. | Speaking cue provided; delivery/rehearsal not verified |
| 4. Relationships and cardinalities | Private regular guide item 4: Use the relationship inspector and the two endpoint counts. | Speaking cue provided; delivery/rehearsal not verified |
| 5. Three Functional Requirements use cases | Private regular guide item 5: Show Create Portfolio Post, Verify Collaboration and Apply for Job. | Speaking cue provided; delivery/rehearsal not verified |
| 6. Data Dictionary and important fields | Private regular guide item 6: Open posts in the dictionary and read the generated examples below. | Speaking cue provided; delivery/rehearsal not verified |
| 7. At least three important business rules | Private regular guide item 7: Create Step 4, Verify Step 2, Apply Step 4; then the Business Rules page. | Speaking cue provided; delivery/rehearsal not verified |
| 8. Sprint I UI review and resulting changes | Private regular guide item 8: Show the supplied screens, then the review-evidence page. | Speaking cue provided; delivery/rehearsal not verified |
| 9. Unresolved questions before Sprint III | Private regular guide item 9: Open the Team Decision Checklist in the Consistency Report. | Speaking cue provided; delivery/rehearsal not verified |
| 10. GitHub evidence | Private regular guide item 10: Open the real team repository in the audience browser and show the files and commit history. | Speaking cue provided; actual Sprint II GitHub evidence unverified |

## Competition coverage

Create Portfolio Post demonstrates content creation and many-to-many skill classification. Verify Collaboration demonstrates an optional decision record, matching company integrity, reviewer authorization and approval state. Apply for Job demonstrates student/job association, owned evidence attachments, uniqueness and coordinated status/history. The same student/post makes reuse explicit while these are different functional operations.

All 15 private step scripts explain entities, connections, cardinality reasoning, stored information, rule purpose and intended enforcement. Exact field references and relationships were checked. Each case’s first step names its corresponding Functional Requirements. The six private checkboxes are a reference-only, manually marked checklist, not proof of delivered speech.

The full master contains 48 tables and 109 FK relationships; dictionary covers 299 fields; nine area views remain. Whole-system Student, Recruiter, Company Representative, Career Advisor and Administrator support is retained. Many-to-many links use the existing associative entities. Logical required children are distinguished from what a foreign key can enforce.

## UI review evidence

Supplied Sprint I page 5 contains Create Post, verification dashboard and Applications Dashboard mockups. The audit documents independent portfolio/feed visibility, separate verification/showcase states, and application notes distinct from status history. The FRD 30–60-second duration and Sprint I up-to-60 wording remain a source discrepancy. Audit changes are documented; a causal claim that each was prompted exclusively by UI review is not established. The guide says that plainly rather than fabricating a changelog.

## Actual verification

Content tests passed all 15 rationale scripts, current-step relationship-ID references, the five dictionary examples’ complete actual metadata, and the ten private guide entries. DATA is identical to the prior candidate, including master visuals, graphs, fields, examples, roles, rules and pending decisions. All existing embedded documents are retained, with an appended public coverage link/page.

Latest geometry/Node VM checks: 240 fits across four canvas sizes and both modes/directions; 2,112 transition containment checks; 60 accumulated Master fits; all 48 table selections and 109 relationship inspections; 15 simulated presenter/audience steps; command retry and disconnect/reconnect; private reminder marking and guide commands. These are model, geometry and DOM/window-stub tests, not end-to-end browser tests.

Browser local-file access remains blocked. No new screenshot/render review, real Chrome/Edge interaction test or Windows Extend/projector synchronization test was performed. Readability and clipping must be checked on the actual presentation setup; the rubric’s ERD-readability criterion is supported by features, not newly visually certified here. GitHub uploads/member contributions, pull records, Sprint II meetings/photos and Scrum Master evidence remain unverified. No remote was modified.
